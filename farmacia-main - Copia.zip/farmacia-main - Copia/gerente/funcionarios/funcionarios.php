<?php
session_start();

require_once __DIR__ . '/../../autenticacao.php';
require_once __DIR__ . '/../conexaoDB.php';
require_once __DIR__ . '/../../cabecalho.php';

exigirLogin('gerente');

$farmaciaId = (int) $_SESSION['farmacia_id'];

$sql = "SELECT id, nome, cpf, telefone, email, login, ativo, criado_em
        FROM usuarios
        WHERE cargo = 'balconista' AND farmacia_id = ?
        ORDER BY nome ASC";

$stmt = mysqli_prepare($conexao, $sql);
mysqli_stmt_bind_param($stmt, 'i', $farmaciaId);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);

$funcionarios = array();
while ($row = mysqli_fetch_assoc($resultado)) {
    $funcionarios[] = $row;
}
mysqli_stmt_close($stmt);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <?php renderHead('FarmaCerta - Funcionários', 2); ?>
</head>
<body>
    <?php cabecalho('FarmaCerta - Funcionários', 'funcionarios', 'funcionarios'); ?>

    <main class="container my-4 flex-grow-1">
        <!-- Header & Cadastrar CTA -->
        <div class="fc-card p-4 mb-4">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
                <div>
                    <h1 class="h4 fw-bold text-dark mb-1">
                        <i class="bi bi-people text-danger me-1"></i> Equipe de Balconistas
                    </h1>
                    <p class="text-muted small mb-0">Gerencie o acesso e o cadastro de colaboradores da sua farmácia.</p>
                </div>
                <div>
                    <button class="btn btn-danger btn-touch rounded-pill px-4 fw-bold shadow-sm" data-bs-toggle="collapse" data-bs-target="#collapseCadastro" aria-expanded="false" aria-controls="collapseCadastro">
                        <i class="bi bi-person-plus-fill fs-5"></i>
                        <span>NOVO BALCONISTA</span>
                    </button>
                </div>
            </div>

            <!-- Formulário de Cadastro (Collapse Suave) -->
            <div class="collapse <?= isset($_GET['erro']) ? 'show' : '' ?>" id="collapseCadastro">
                <div class="p-4 bg-light rounded-4 border mt-3">
                    <h2 class="h5 fw-bold text-dark mb-3">
                        <i class="bi bi-person-badge text-danger"></i> Formulário de Cadastro de Balconista
                    </h2>

                    <?php if (isset($_GET['erro'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show rounded-3 shadow-sm mb-3" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i>
                            <?= htmlspecialchars($_GET['erro']) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <form action="cadastrarfuncionario.php" method="POST">
                        <div class="row g-3">
                            <div class="col-12 col-md-6">
                                <label class="form-label small fw-bold text-secondary">Nome Completo *</label>
                                <input type="text" name="nome" class="form-control form-control-touch" placeholder="Ex: Carlos Oliveira" required>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label small fw-bold text-secondary">CPF *</label>
                                <input type="text" name="cpf" class="form-control form-control-touch" placeholder="000.000.000-00" maxlength="14" inputmode="numeric" required>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label small fw-bold text-secondary">Telefone / WhatsApp</label>
                                <input type="text" name="telefone" class="form-control form-control-touch" placeholder="(00) 00000-0000" maxlength="15" inputmode="numeric">
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label small fw-bold text-secondary">E-mail</label>
                                <input type="email" name="email" class="form-control form-control-touch" placeholder="nome@exemplo.com">
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label small fw-bold text-secondary">Data de Nascimento</label>
                                <input type="date" name="nascimento" class="form-control form-control-touch">
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label small fw-bold text-secondary">Usuário para Login *</label>
                                <input type="text" name="login" class="form-control form-control-touch" placeholder="Ex: carlos.oliveira" required>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label small fw-bold text-secondary">Senha de Acesso (Mínimo 6 dígitos) *</label>
                                <input type="password" name="senha" class="form-control form-control-touch" placeholder="******" required minlength="6">
                            </div>
                        </div>

                        <div class="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                            <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-toggle="collapse" data-bs-target="#collapseCadastro">
                                Cancelar
                            </button>
                            <button type="submit" class="btn btn-danger rounded-pill px-4 fw-bold">
                                <i class="bi bi-check2"></i> Salvar Balconista
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Feedback Messages -->
        <?php if (isset($_GET['ok'])): ?>
            <div class="alert alert-success alert-dismissible fade show rounded-3 shadow-sm d-flex align-items-center gap-2 mb-4" role="alert">
                <i class="bi bi-check-circle-fill fs-5"></i>
                <div>Operação realizada com sucesso!</div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Visão Mobile (Cards de Funcionários) -->
        <div class="d-md-none">
            <?php if (empty($funcionarios)): ?>
                <div class="fc-card p-4 text-center text-muted">
                    Nenhum balconista cadastrado no momento.
                </div>
            <?php endif; ?>

            <?php foreach ($funcionarios as $f): 
                $ativo = (int)$f['ativo'] === 1;
            ?>
                <div class="fc-card p-3 mb-3 <?= !$ativo ? 'opacity-75' : '' ?>">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="badge <?= $ativo ? 'bg-success' : 'bg-secondary' ?> rounded-pill">
                            <?= $ativo ? 'Ativo' : 'Inativo' ?>
                        </span>
                        <span class="text-muted small">Login: <strong><?= htmlspecialchars($f['login']) ?></strong></span>
                    </div>
                    <h2 class="h6 fw-bold text-dark mb-1"><?= htmlspecialchars($f['nome']) ?></h2>
                    <div class="text-muted small mb-2">
                        <div><i class="bi bi-card-heading me-1"></i> CPF: <?= htmlspecialchars($f['cpf'] ?: '—') ?></div>
                        <div><i class="bi bi-telephone me-1"></i> <?= htmlspecialchars($f['telefone'] ?: '—') ?></div>
                    </div>
                    <div class="pt-2 border-top mt-2">
                        <a 
                            href="alterarstatus.php?id=<?= $f['id'] ?>" 
                            class="btn btn-sm <?= $ativo ? 'btn-outline-danger' : 'btn-outline-success' ?> rounded-pill w-100 fw-bold"
                            onclick="return confirm('Deseja <?= $ativo ? 'desativar' : 'ativar' ?> o balconista <?= htmlspecialchars($f['nome']) ?>?');"
                        >
                            <i class="bi <?= $ativo ? 'bi-person-x' : 'bi-person-check' ?>"></i>
                            <?= $ativo ? 'Desativar Acesso' : 'Reativar Acesso' ?>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Visão Desktop (Tabela) -->
        <div class="d-none d-md-block fc-card p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4">Nome do Balconista</th>
                            <th>Login</th>
                            <th>CPF</th>
                            <th>Telefone</th>
                            <th>Status</th>
                            <th class="text-end pe-4">Ação</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($funcionarios)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-5 text-muted">
                                    Nenhum balconista cadastrado no momento.
                                </td>
                            </tr>
                        <?php endif; ?>

                        <?php foreach ($funcionarios as $f): 
                            $ativo = (int)$f['ativo'] === 1;
                        ?>
                            <tr class="<?= !$ativo ? 'opacity-75 bg-light' : '' ?>">
                                <td class="ps-4 fw-bold text-dark"><?= htmlspecialchars($f['nome']) ?></td>
                                <td><code><?= htmlspecialchars($f['login']) ?></code></td>
                                <td><?= htmlspecialchars($f['cpf'] ?: '—') ?></td>
                                <td><?= htmlspecialchars($f['telefone'] ?: '—') ?></td>
                                <td>
                                    <span class="badge <?= $ativo ? 'bg-success-subtle text-success border border-success' : 'bg-secondary-subtle text-secondary border border-secondary' ?> rounded-pill px-3 py-1">
                                        <?= $ativo ? 'Ativo' : 'Inativo' ?>
                                    </span>
                                </td>
                                <td class="text-end pe-4">
                                    <a 
                                        href="alterarstatus.php?id=<?= $f['id'] ?>" 
                                        class="btn btn-sm <?= $ativo ? 'btn-outline-danger' : 'btn-outline-success' ?> rounded-pill px-3 fw-bold"
                                        onclick="return confirm('Deseja <?= $ativo ? 'desativar' : 'ativar' ?> o balconista <?= htmlspecialchars($f['nome']) ?>?');"
                                    >
                                        <i class="bi <?= $ativo ? 'bi-person-x' : 'bi-person-check' ?>"></i>
                                        <?= $ativo ? 'Desativar' : 'Ativar' ?>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <?php renderScripts(2); ?>
</body>
</html>
