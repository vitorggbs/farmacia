<?php
session_start();

require_once __DIR__ . '/../autenticacao.php';
require_once __DIR__ . '/conexaoDB.php';
require_once __DIR__ . '/../cabecalho.php';

exigirLogin('gerente');

$farmaciaId = (int) $_SESSION['farmacia_id'];
$nomeFarmacia = $_SESSION['farmacia_nome'] ?? 'Farmácia';
$nomeUsuario = $_SESSION['usuario_nome'] ?? 'Gerente';

function buscarResumo($conexao, $farmaciaId, $condicao)
{
    $sql = "SELECT COUNT(*) AS vendas,
            COALESCE(SUM(valor_total), 0) AS total,
            COALESCE(AVG(valor_total), 0) AS media
            FROM vendas
            WHERE farmacia_id = ? AND $condicao";

    $stmt = mysqli_prepare($conexao, $sql);
    mysqli_stmt_bind_param($stmt, 'i', $farmaciaId);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
    $dados = mysqli_fetch_assoc($resultado);
    mysqli_stmt_close($stmt);

    return $dados;
}

$resumoDia = buscarResumo($conexao, $farmaciaId, 'DATE(data_venda) = CURDATE()');
$resumoMes = buscarResumo($conexao, $farmaciaId, 'YEAR(data_venda) = YEAR(CURDATE()) AND MONTH(data_venda) = MONTH(CURDATE())');

// Faturamento dos últimos 7 dias
$sql = 'SELECT DATE(data_venda) AS dia, COALESCE(SUM(valor_total), 0) AS total
        FROM vendas
        WHERE farmacia_id = ?
        AND DATE(data_venda) BETWEEN DATE_SUB(CURDATE(), INTERVAL 6 DAY) AND CURDATE()
        GROUP BY DATE(data_venda)
        ORDER BY dia';
$stmt = mysqli_prepare($conexao, $sql);
mysqli_stmt_bind_param($stmt, 'i', $farmaciaId);
mysqli_stmt_execute($stmt);
$resultadoFaturamento = mysqli_stmt_get_result($stmt);
$faturamentoPorDia = array();
while ($linha = mysqli_fetch_assoc($resultadoFaturamento)) {
    $faturamentoPorDia[$linha['dia']] = (float) $linha['total'];
}
mysqli_stmt_close($stmt);

$graficoDias = array();
$graficoValores = array();
for ($i = 6; $i >= 0; $i--) {
    $data = date('Y-m-d', strtotime("-$i day"));
    $graficoDias[] = date('d/m', strtotime($data));
    $graficoValores[] = isset($faturamentoPorDia[$data]) ? $faturamentoPorDia[$data] : 0;
}

// Produtos com estoque baixo
$sql = 'SELECT id, nome, quantidade, estoque_minimo, imagem, preco, prateleira
        FROM produtos
        WHERE farmacia_id = ? AND ativo = 1 AND quantidade <= estoque_minimo
        ORDER BY quantidade ASC, nome ASC
        LIMIT 6';
$stmt = mysqli_prepare($conexao, $sql);
mysqli_stmt_bind_param($stmt, 'i', $farmaciaId);
mysqli_stmt_execute($stmt);
$produtosBaixo = mysqli_stmt_get_result($stmt);

$estoqueBaixo = array();
while ($produto = mysqli_fetch_assoc($produtosBaixo)) {
    $estoqueBaixo[] = $produto;
}
mysqli_stmt_close($stmt);

// Contagem total de produtos com estoque baixo
$sqlContagemBaixo = 'SELECT COUNT(*) AS total FROM produtos WHERE farmacia_id = ? AND ativo = 1 AND quantidade <= estoque_minimo';
$stmtCB = mysqli_prepare($conexao, $sqlContagemBaixo);
mysqli_stmt_bind_param($stmtCB, 'i', $farmaciaId);
mysqli_stmt_execute($stmtCB);
$resCB = mysqli_stmt_get_result($stmtCB);
$totalEstoqueBaixoQtd = mysqli_fetch_assoc($resCB)['total'] ?? 0;
mysqli_stmt_close($stmtCB);

// Últimas vendas
$sql = 'SELECT v.id, v.data_venda, v.forma_pagamento, v.valor_total,
        COALESCE(NULLIF(v.cliente, ""), "Consumidor Final") AS cliente,
        u.nome AS balconista
        FROM vendas v
        INNER JOIN usuarios u ON u.id = v.usuario_id
        WHERE v.farmacia_id = ?
        ORDER BY v.id DESC
        LIMIT 6';
$stmt = mysqli_prepare($conexao, $sql);
mysqli_stmt_bind_param($stmt, 'i', $farmaciaId);
mysqli_stmt_execute($stmt);
$ultimas = mysqli_stmt_get_result($stmt);

$ultimasVendas = array();
while ($venda = mysqli_fetch_assoc($ultimas)) {
    $ultimasVendas[] = $venda;
}
mysqli_stmt_close($stmt);

// Formas de Pagamento no Mês
$formas = array(
    'dinheiro' => 0.0,
    'debito' => 0.0,
    'credito' => 0.0,
    'pix' => 0.0
);

$sql = 'SELECT forma_pagamento, COALESCE(SUM(valor_total), 0) AS total
        FROM vendas
        WHERE farmacia_id = ?
        AND YEAR(data_venda) = YEAR(CURDATE())
        AND MONTH(data_venda) = MONTH(CURDATE())
        GROUP BY forma_pagamento';
$stmt = mysqli_prepare($conexao, $sql);
mysqli_stmt_bind_param($stmt, 'i', $farmaciaId);
mysqli_stmt_execute($stmt);
$resultadoFormas = mysqli_stmt_get_result($stmt);
while ($forma = mysqli_fetch_assoc($resultadoFormas)) {
    $fp = strtolower($forma['forma_pagamento']);
    if (isset($formas[$fp])) {
        $formas[$fp] = (float) $forma['total'];
    }
}
mysqli_stmt_close($stmt);
$totalPagamentos = array_sum($formas);

// Pontos para o gráfico SVG Responsivo
$maiorGrafico = max($graficoValores);
if ($maiorGrafico <= 0) {
    $maiorGrafico = 1;
}

$pontosGrafico = array();
$areaGrafico = array('0,180');
foreach ($graficoValores as $indice => $valor) {
    $x = ($indice / 6) * 600;
    $y = 180 - (($valor / $maiorGrafico) * 145);
    $pontosGrafico[] = round($x, 2) . ',' . round($y, 2);
    $areaGrafico[] = round($x, 2) . ',' . round($y, 2);
}
$areaGrafico[] = '600,180';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <?php renderHead('FarmaCerta - Painel do Gerente', 1); ?>
    <style>
        .chart-container {
            width: 100%;
            height: 220px;
            position: relative;
        }
        .chart-container svg {
            width: 100%;
            height: 100%;
            overflow: visible;
        }
    </style>
</head>
<body>
    <?php cabecalho('FarmaCerta - Gerente', 'gerente', 'inicio'); ?>

    <main class="container my-4 flex-grow-1">
        <!-- Boas-vindas -->
        <div class="fc-card p-4 mb-4 border-0">
            <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">
                <div>
                    <span class="badge bg-danger-subtle text-danger px-3 py-2 rounded-pill fw-bold mb-2">
                        <i class="bi bi-shop me-1"></i> <?= htmlspecialchars($nomeFarmacia) ?>
                    </span>
                    <h1 class="h3 fw-bold mb-1 text-dark">Painel de Gestão &mdash; <?= htmlspecialchars($nomeUsuario) ?></h1>
                    <p class="text-muted mb-0">Visão consolidada de faturamento, vendas e estoque em tempo real.</p>
                </div>
                <div class="d-flex flex-wrap gap-2">
                    <a href="produtosgerente.php" class="btn btn-danger btn-touch rounded-pill px-4 fw-bold">
                        <i class="bi bi-box-seam"></i> Gerenciar Produtos
                    </a>
                    <a href="movimentacoesestoque.php" class="btn btn-outline-secondary btn-touch rounded-pill px-3">
                        <i class="bi bi-arrow-left-right"></i> Movimentações
                    </a>
                </div>
            </div>
        </div>

        <!-- 4 KPIs Principais -->
        <div class="row g-3 mb-4">
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="kpi-card h-100">
                    <div class="kpi-icon primary">
                        <i class="bi bi-calendar-check"></i>
                    </div>
                    <div>
                        <div class="text-muted small text-uppercase fw-bold">Vendas Hoje</div>
                        <div class="fs-3 fw-bold text-dark"><?= (int)$resumoDia['vendas'] ?></div>
                        <small class="text-secondary">R$ <?= number_format($resumoDia['total'], 2, ',', '.') ?></small>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-xl-3">
                <div class="kpi-card h-100">
                    <div class="kpi-icon success">
                        <i class="bi bi-cash-stack"></i>
                    </div>
                    <div>
                        <div class="text-muted small text-uppercase fw-bold">Faturamento Mês</div>
                        <div class="fs-4 fw-bold text-success">R$ <?= number_format($resumoMes['total'], 2, ',', '.') ?></div>
                        <small class="text-secondary"><?= (int)$resumoMes['vendas'] ?> vendas no mês</small>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-xl-3">
                <div class="kpi-card h-100">
                    <div class="kpi-icon info">
                        <i class="bi bi-calculator"></i>
                    </div>
                    <div>
                        <div class="text-muted small text-uppercase fw-bold">Ticket Médio</div>
                        <div class="fs-4 fw-bold text-dark">R$ <?= number_format($resumoMes['media'], 2, ',', '.') ?></div>
                        <small class="text-secondary">Por atendimento</small>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-xl-3">
                <div class="kpi-card h-100">
                    <div class="kpi-icon <?= $totalEstoqueBaixoQtd > 0 ? 'warning' : 'success' ?>">
                        <i class="bi bi-exclamation-triangle-fill"></i>
                    </div>
                    <div>
                        <div class="text-muted small text-uppercase fw-bold">Alerta de Estoque</div>
                        <div class="fs-3 fw-bold <?= $totalEstoqueBaixoQtd > 0 ? 'text-danger' : 'text-success' ?>">
                            <?= (int)$totalEstoqueBaixoQtd ?>
                        </div>
                        <small class="text-secondary">Itens abaixo do mínimo</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Gráfico e Formas de Pagamento -->
        <div class="row g-4 mb-4">
            <!-- Gráfico 7 Dias -->
            <div class="col-12 col-lg-8">
                <div class="fc-card p-4 h-100">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h2 class="h5 fw-bold text-dark mb-0 d-flex align-items-center gap-2">
                            <i class="bi bi-graph-up text-danger"></i> Faturamento nos Últimos 7 Dias
                        </h2>
                        <span class="badge bg-light text-secondary border rounded-pill px-3 py-1">Semana Atual</span>
                    </div>

                    <div class="chart-container py-2">
                        <svg viewBox="0 0 600 200" preserveAspectRatio="none">
                            <defs>
                                <linearGradient id="gradienteGrafico" x1="0%" y1="0%" x2="0%" y2="100%">
                                    <stop offset="0%" stop-color="#d62828" stop-opacity="0.35" />
                                    <stop offset="100%" stop-color="#d62828" stop-opacity="0.0" />
                                </linearGradient>
                            </defs>

                            <!-- Linhas de grade horizontais -->
                            <line x1="0" y1="35" x2="600" y2="35" stroke="#f1f5f9" stroke-width="1" />
                            <line x1="0" y1="85" x2="600" y2="85" stroke="#f1f5f9" stroke-width="1" />
                            <line x1="0" y1="135" x2="600" y2="135" stroke="#f1f5f9" stroke-width="1" />
                            <line x1="0" y1="180" x2="600" y2="180" stroke="#e2e8f0" stroke-width="1.5" />

                            <!-- Área preenchida -->
                            <polygon points="<?= implode(' ', $areaGrafico) ?>" fill="url(#gradienteGrafico)" />

                            <!-- Linha principal -->
                            <polyline points="<?= implode(' ', $pontosGrafico) ?>" fill="none" stroke="#d62828" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" />

                            <!-- Pontos nos vértices -->
                            <?php foreach ($graficoValores as $idx => $val): 
                                $px = ($idx / 6) * 600;
                                $py = 180 - (($val / $maiorGrafico) * 145);
                            ?>
                                <circle cx="<?= $px ?>" cy="<?= $py ?>" r="5" fill="#ffffff" stroke="#d62828" stroke-width="3" />
                            <?php endforeach; ?>
                        </svg>
                    </div>

                    <!-- Legenda dos Dias -->
                    <div class="d-flex justify-content-between pt-2 text-muted small border-top mt-2">
                        <?php foreach ($graficoDias as $idx => $dia): ?>
                            <div class="text-center">
                                <div class="fw-bold"><?= $dia ?></div>
                                <div class="text-secondary small">R$ <?= number_format($graficoValores[$idx], 0, ',', '.') ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Formas de Pagamento -->
            <div class="col-12 col-lg-4">
                <div class="fc-card p-4 h-100">
                    <h2 class="h5 fw-bold text-dark mb-3 d-flex align-items-center gap-2">
                        <i class="bi bi-pie-chart text-danger"></i> Pagamentos no Mês
                    </h2>

                    <div class="p-3 bg-light rounded-3 mb-3 text-center border">
                        <div class="text-muted small text-uppercase">Total Recebido</div>
                        <div class="fs-4 fw-bold text-dark">R$ <?= number_format($totalPagamentos, 2, ',', '.') ?></div>
                    </div>

                    <div class="d-flex flex-column gap-3">
                        <?php 
                        $nomesFormas = array(
                            'dinheiro' => array('Dinheiro', 'bi-cash', 'bg-success'),
                            'pix' => array('Pix', 'bi-lightning-charge-fill', 'bg-info'),
                            'debito' => array('Débito', 'bi-credit-card', 'bg-primary'),
                            'credito' => array('Crédito', 'bi-credit-card-2-front', 'bg-danger')
                        );
                        foreach ($formas as $chave => $val):
                            $pct = $totalPagamentos > 0 ? ($val / $totalPagamentos) * 100 : 0;
                            $info = $nomesFormas[$chave] ?? array(ucfirst($chave), 'bi-cash', 'bg-secondary');
                        ?>
                            <div>
                                <div class="d-flex justify-content-between small fw-bold mb-1">
                                    <span><i class="bi <?= $info[1] ?> me-1"></i> <?= $info[0] ?></span>
                                    <span>R$ <?= number_format($val, 2, ',', '.') ?> (<?= number_format($pct, 1, ',', '.') ?>%)</span>
                                </div>
                                <div class="progress" style="height: 8px;">
                                    <div class="progress-bar <?= $info[2] ?>" role="progressbar" style="width: <?= $pct ?>%;" aria-valuenow="<?= $pct ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tabelas Resumo: Estoque Baixo & Últimas Vendas -->
        <div class="row g-4">
            <!-- Estoque Baixo -->
            <div class="col-12 col-lg-6">
                <div class="fc-card p-4 h-100">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h2 class="h5 fw-bold text-dark mb-0 d-flex align-items-center gap-2">
                            <i class="bi bi-box-seam text-danger"></i> Produtos com Estoque Baixo
                        </h2>
                        <a href="produtosgerente.php" class="btn btn-sm btn-outline-danger rounded-pill px-3">
                            Ver Todos
                        </a>
                    </div>

                    <?php if (empty($estoqueBaixo)): ?>
                        <div class="text-center py-4 text-muted">
                            <i class="bi bi-check-circle fs-2 d-block text-success mb-2"></i>
                            Nenhum produto em nível crítico de estoque.
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0 small">
                                <thead class="table-light">
                                    <tr>
                                        <th>Produto</th>
                                        <th class="text-center">Estoque</th>
                                        <th class="text-center">Mínimo</th>
                                        <th class="text-end">Ação</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($estoqueBaixo as $pb): ?>
                                        <tr>
                                            <td class="fw-bold text-dark"><?= htmlspecialchars($pb['nome']) ?></td>
                                            <td class="text-center">
                                                <span class="badge <?= $pb['quantidade'] <= 0 ? 'bg-danger' : 'bg-warning text-dark' ?> rounded-pill">
                                                    <?= (int)$pb['quantidade'] ?> un
                                                </span>
                                            </td>
                                            <td class="text-center text-muted"><?= (int)$pb['estoque_minimo'] ?> un</td>
                                            <td class="text-end">
                                                <a href="produtosgerente.php" class="btn btn-sm btn-outline-primary rounded-pill px-2 py-1">
                                                    Repor
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Últimas Vendas -->
            <div class="col-12 col-lg-6">
                <div class="fc-card p-4 h-100">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h2 class="h5 fw-bold text-dark mb-0 d-flex align-items-center gap-2">
                            <i class="bi bi-receipt text-danger"></i> Últimas Vendas Realizadas
                        </h2>
                        <a href="historicorecibogerente.php" class="btn btn-sm btn-outline-secondary rounded-pill px-3">
                            Ver Histórico
                        </a>
                    </div>

                    <?php if (empty($ultimasVendas)): ?>
                        <div class="text-center py-4 text-muted">
                            <i class="bi bi-inbox fs-2 d-block text-secondary mb-2"></i>
                            Nenhuma venda registrada até o momento.
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0 small">
                                <thead class="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Cliente</th>
                                        <th>Balconista</th>
                                        <th>Valor</th>
                                        <th class="text-end">Recibo</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($ultimasVendas as $uv): ?>
                                        <tr>
                                            <td class="fw-bold text-danger">#<?= $uv['id'] ?></td>
                                            <td><?= htmlspecialchars($uv['cliente']) ?></td>
                                            <td class="text-muted"><?= htmlspecialchars($uv['balconista']) ?></td>
                                            <td class="fw-bold text-success">R$ <?= number_format($uv['valor_total'], 2, ',', '.') ?></td>
                                            <td class="text-end">
                                                <a href="../balconista/recibobalconista.php?id=<?= $uv['id'] ?>" class="btn btn-sm btn-outline-danger rounded-pill px-2 py-1">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <?php renderScripts(1); ?>
</body>
</html>
