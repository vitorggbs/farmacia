<?php
session_start();

require_once __DIR__ . '/../autenticacao.php';
require_once __DIR__ . '/conexaoDB.php';
require_once __DIR__ . '/../cabecalho.php';

exigirLogin('gerente');

$farmaciaId = (int) $_SESSION['farmacia_id'];
$nomeFarmacia = $_SESSION['farmacia_nome'] ?? 'Farmácia';

$sql = 'SELECT * FROM produtos WHERE farmacia_id = ? AND ativo = 1 ORDER BY nome ASC';
$stmt = mysqli_prepare($conexao, $sql);
mysqli_stmt_bind_param($stmt, 'i', $farmaciaId);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);

$produtos = array();
while ($row = mysqli_fetch_assoc($resultado)) {
    $produtos[] = $row;
}
mysqli_stmt_close($stmt);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <?php renderHead('FarmaCerta - Gestão de Produtos', 1); ?>
</head>
<body>
    <?php cabecalho('FarmaCerta - Gerente', 'gerente', 'produtos'); ?>

    <main class="container my-4 flex-grow-1">
        <!-- Topo & Ações -->
        <div class="fc-card p-4 mb-4">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
                <div>
                    <h1 class="h4 fw-bold text-dark mb-1">
                        <i class="bi bi-box-seam text-danger me-1"></i> Gestão de Produtos e Estoque
                    </h1>
                    <p class="text-muted small mb-0">Cadastre, edite, reponha e acompanhe os níveis de medicamentos.</p>
                </div>
                <div class="d-flex gap-2">
                    <button class="btn btn-danger btn-touch rounded-pill px-4 fw-bold shadow-sm" data-bs-toggle="modal" data-bs-target="#modalNovoProduto">
                        <i class="bi bi-plus-circle-fill fs-5"></i>
                        <span>CADASTRAR PRODUTO</span>
                    </button>
                </div>
            </div>

            <hr class="my-3 text-muted opacity-25">

            <!-- Busca Instantânea -->
            <div class="input-group input-group-lg rounded-pill overflow-hidden border">
                <span class="input-group-text bg-white border-0 ps-3">
                    <i class="bi bi-search text-danger"></i>
                </span>
                <input 
                    type="text" 
                    id="buscaProdutoInput" 
                    class="form-control border-0 ps-2 fs-6" 
                    placeholder="Pesquisar por nome do produto ou prateleira..." 
                    onkeyup="filtrarProdutosGerente()"
                >
            </div>
        </div>

        <!-- Feedback Alerts -->
        <?php if (isset($_GET['cadastro'])): ?>
            <div class="alert alert-success alert-dismissible fade show rounded-3 shadow-sm d-flex align-items-center gap-2 mb-4" role="alert">
                <i class="bi bi-check-circle-fill fs-5"></i>
                <div>Produto cadastrado com sucesso no sistema!</div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($_GET['ok']) && $_GET['ok'] === 'editado'): ?>
            <div class="alert alert-success alert-dismissible fade show rounded-3 shadow-sm d-flex align-items-center gap-2 mb-4" role="alert">
                <i class="bi bi-check-circle-fill fs-5"></i>
                <div>Alterações salvas com sucesso!</div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($_GET['ok']) && $_GET['ok'] === 'reposto'): ?>
            <div class="alert alert-success alert-dismissible fade show rounded-3 shadow-sm d-flex align-items-center gap-2 mb-4" role="alert">
                <i class="bi bi-check-circle-fill fs-5"></i>
                <div>Estoque reposto com sucesso e movimentação registrada!</div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($_GET['excluido'])): ?>
            <div class="alert alert-warning alert-dismissible fade show rounded-3 shadow-sm d-flex align-items-center gap-2 mb-4" role="alert">
                <i class="bi bi-trash-fill fs-5"></i>
                <div>Produto desativado com sucesso.</div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Visão Mobile (Cards Touch-Friendly) -->
        <div class="d-md-none" id="produtosMobileList">
            <?php if (empty($produtos)): ?>
                <div class="fc-card p-4 text-center text-muted">
                    Nenhum produto cadastrado nesta farmácia.
                </div>
            <?php endif; ?>

            <?php foreach ($produtos as $p): 
                $semEstoque = ($p['quantidade'] <= 0);
                $estoqueBaixo = ($p['quantidade'] <= $p['estoque_minimo']);
            ?>
                <div class="fc-card p-3 mb-3 card-produto-item" data-nome="<?= mb_strtolower($p['nome']) ?>" data-prat="<?= mb_strtolower($p['prateleira'] ?? '') ?>">
                    <div class="d-flex gap-3 align-items-start mb-2">
                        <div style="width: 70px; height: 70px; flex-shrink: 0;">
                            <?php if (!empty($p['imagem']) && file_exists(__DIR__ . '/uploads/' . $p['imagem'])): ?>
                                <img src="uploads/<?= htmlspecialchars($p['imagem']) ?>" alt="<?= htmlspecialchars($p['nome']) ?>" class="w-100 h-100 rounded-3 object-fit-cover border">
                            <?php else: ?>
                                <div class="w-100 h-100 rounded-3 bg-light d-flex align-items-center justify-content-center text-secondary border">
                                    <i class="bi bi-capsule fs-4"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="flex-grow-1">
                            <h2 class="h6 fw-bold text-dark mb-1"><?= htmlspecialchars($p['nome']) ?></h2>
                            <div class="d-flex align-items-center gap-2 mb-1">
                                <span class="badge <?= $semEstoque ? 'bg-danger' : ($estoqueBaixo ? 'bg-warning text-dark' : 'bg-success-subtle text-success border border-success') ?> rounded-pill small">
                                    <?= $semEstoque ? 'Sem Estoque' : 'Estoque: ' . (int)$p['quantidade'] . ' un' ?>
                                </span>
                                <span class="badge bg-light text-secondary border rounded-pill small">
                                    Prat: <?= htmlspecialchars($p['prateleira'] ?: '—') ?>
                                </span>
                            </div>
                            <div class="fs-6 fw-bold text-danger">
                                R$ <?= number_format($p['preco'], 2, ',', '.') ?>
                            </div>
                        </div>
                    </div>

                    <!-- Ações Mobile -->
                    <div class="d-flex gap-2 pt-2 border-top mt-2">
                        <button 
                            class="btn btn-sm btn-outline-success flex-fill rounded-pill fw-bold"
                            onclick='abrirModalRepor(<?= json_encode($p) ?>)'
                        >
                            <i class="bi bi-plus-lg"></i> Repor
                        </button>
                        <button 
                            class="btn btn-sm btn-outline-primary flex-fill rounded-pill fw-bold"
                            onclick='abrirModalEditar(<?= json_encode($p) ?>)'
                        >
                            <i class="bi bi-pencil"></i> Editar
                        </button>
                        <a 
                            href="excluirproduto.php?id=<?= $p['id'] ?>" 
                            class="btn btn-sm btn-outline-danger rounded-pill px-3"
                            onclick="return confirm('Deseja realmente desativar o produto <?= htmlspecialchars($p['nome']) ?>?');"
                            title="Desativar Produto"
                        >
                            <i class="bi bi-trash"></i>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Visão Desktop (Tabela Completa) -->
        <div class="d-none d-md-block fc-card p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" id="tabelaDesktopProdutosGerente">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4" style="width: 70px;">Foto</th>
                            <th>Produto</th>
                            <th>Preço</th>
                            <th>Estoque</th>
                            <th>Est. Mínimo</th>
                            <th>Prateleira</th>
                            <th class="text-end pe-4" style="width: 260px;">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($produtos)): ?>
                            <tr>
                                <td colspan="7" class="text-center py-5 text-muted">
                                    Nenhum produto cadastrado no momento.
                                </td>
                            </tr>
                        <?php endif; ?>

                        <?php foreach ($produtos as $p): 
                            $semEstoque = ($p['quantidade'] <= 0);
                            $estoqueBaixo = ($p['quantidade'] <= $p['estoque_minimo']);
                        ?>
                            <tr class="linha-produto-item" data-nome="<?= mb_strtolower($p['nome']) ?>" data-prat="<?= mb_strtolower($p['prateleira'] ?? '') ?>">
                                <td class="ps-4">
                                    <?php if (!empty($p['imagem']) && file_exists(__DIR__ . '/uploads/' . $p['imagem'])): ?>
                                        <img src="uploads/<?= htmlspecialchars($p['imagem']) ?>" alt="<?= htmlspecialchars($p['nome']) ?>" width="48" height="48" class="rounded-3 object-fit-cover border">
                                    <?php else: ?>
                                        <div class="rounded-3 bg-light d-flex align-items-center justify-content-center text-secondary border" style="width: 48px; height: 48px;">
                                            <i class="bi bi-capsule fs-5"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td class="fw-bold text-dark"><?= htmlspecialchars($p['nome']) ?></td>
                                <td class="fw-bold text-danger">R$ <?= number_format($p['preco'], 2, ',', '.') ?></td>
                                <td>
                                    <?php if ($semEstoque): ?>
                                        <span class="badge bg-danger rounded-pill px-3 py-1">0 un (Esgotado)</span>
                                    <?php elseif ($estoqueBaixo): ?>
                                        <span class="badge bg-warning text-dark rounded-pill px-3 py-1">
                                            <?= (int)$p['quantidade'] ?> un (Baixo)
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-success-subtle text-success border border-success rounded-pill px-3 py-1">
                                            <?= (int)$p['quantidade'] ?> un
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-muted"><?= (int)$p['estoque_minimo'] ?> un</td>
                                <td>
                                    <span class="badge bg-light text-secondary border rounded-pill px-2 py-1">
                                        <?= htmlspecialchars($p['prateleira'] ?: '—') ?>
                                    </span>
                                </td>
                                <td class="text-end pe-4">
                                    <button 
                                        class="btn btn-sm btn-outline-success rounded-pill px-3 fw-bold me-1"
                                        onclick='abrirModalRepor(<?= json_encode($p) ?>)'
                                        title="Repor Estoque"
                                    >
                                        <i class="bi bi-plus-lg"></i> Repor
                                    </button>
                                    <button 
                                        class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-bold me-1"
                                        onclick='abrirModalEditar(<?= json_encode($p) ?>)'
                                        title="Editar Informações"
                                    >
                                        <i class="bi bi-pencil"></i> Editar
                                    </button>
                                    <a 
                                        href="excluirproduto.php?id=<?= $p['id'] ?>" 
                                        class="btn btn-sm btn-outline-danger rounded-pill px-2"
                                        onclick="return confirm('Deseja realmente desativar o produto <?= htmlspecialchars($p['nome']) ?>?');"
                                        title="Desativar Produto"
                                    >
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- ========================================================== -->
    <!-- MODAL 1: CADASTRAR PRODUTO                                  -->
    <!-- ========================================================== -->
    <div class="modal fade" id="modalNovoProduto" tabindex="-1" aria-labelledby="modalNovoProdutoLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content rounded-4 border-0 shadow-lg">
                <div class="modal-header bg-danger text-white rounded-top-4">
                    <h5 class="modal-title fw-bold" id="modalNovoProdutoLabel">
                        <i class="bi bi-plus-circle me-1"></i> Cadastrar Novo Produto
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <form action="cadastrargerente.php" method="POST" enctype="multipart/form-data">
                    <div class="modal-body p-4">
                        <div class="row g-3">
                            <div class="col-12 col-md-8">
                                <label class="form-label small fw-bold text-secondary">Nome do Produto / Medicamento *</label>
                                <input type="text" name="nomeProduto" class="form-control form-control-touch" placeholder="Ex: Dipirona 500mg 20 Comprimidos" required>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label small fw-bold text-secondary">Preço de Venda (R$) *</label>
                                <input type="number" step="0.01" min="0" name="valor" class="form-control form-control-touch" placeholder="0.00" required>
                            </div>
                            <div class="col-12 col-sm-4">
                                <label class="form-label small fw-bold text-secondary">Quantidade Inicial *</label>
                                <input type="number" min="0" name="quantidade" class="form-control form-control-touch" placeholder="0" required>
                            </div>
                            <div class="col-12 col-sm-4">
                                <label class="form-label small fw-bold text-secondary">Estoque Mínimo de Alerta *</label>
                                <input type="number" min="0" name="estoque_minimo" class="form-control form-control-touch" value="5" required>
                            </div>
                            <div class="col-12 col-sm-4">
                                <label class="form-label small fw-bold text-secondary">Local / Prateleira *</label>
                                <input type="text" name="prateleira" class="form-control form-control-touch" placeholder="Ex: A3, Gaveta 2" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-bold text-secondary">Foto do Produto (PNG/JPG) *</label>
                                <input type="file" name="imagem" accept="image/*" class="form-control form-control-touch" required>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light rounded-bottom-4 p-3">
                        <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger rounded-pill px-4 fw-bold">
                            <i class="bi bi-check2"></i> Salvar Produto
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ========================================================== -->
    <!-- MODAL 2: EDITAR PRODUTO                                    -->
    <!-- ========================================================== -->
    <div class="modal fade" id="modalEditarProduto" tabindex="-1" aria-labelledby="modalEditarProdutoLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content rounded-4 border-0 shadow-lg">
                <div class="modal-header bg-primary text-white rounded-top-4">
                    <h5 class="modal-title fw-bold" id="modalEditarProdutoLabel">
                        <i class="bi bi-pencil-square me-1"></i> Editar Informações do Produto
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <form action="editarproduto.php" method="POST">
                    <input type="hidden" name="produto_id" id="edit_produto_id">
                    <div class="modal-body p-4">
                        <div class="mb-3">
                            <label class="form-label small fw-bold text-secondary">Nome do Produto *</label>
                            <input type="text" name="nome" id="edit_nome" class="form-control form-control-touch" required>
                        </div>
                        <div class="row g-3 mb-3">
                            <div class="col-6">
                                <label class="form-label small fw-bold text-secondary">Preço (R$) *</label>
                                <input type="number" step="0.01" min="0" name="preco" id="edit_preco" class="form-control form-control-touch" required>
                            </div>
                            <div class="col-6">
                                <label class="form-label small fw-bold text-secondary">Estoque Mínimo *</label>
                                <input type="number" min="0" name="estoque_minimo" id="edit_estoque_minimo" class="form-control form-control-touch" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold text-secondary">Prateleira / Localização *</label>
                            <input type="text" name="prateleira" id="edit_prateleira" class="form-control form-control-touch" required>
                        </div>
                    </div>
                    <div class="modal-footer bg-light rounded-bottom-4 p-3">
                        <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary rounded-pill px-4 fw-bold">
                            <i class="bi bi-check2"></i> Salvar Alterações
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ========================================================== -->
    <!-- MODAL 3: REPOR ESTOQUE                                     -->
    <!-- ========================================================== -->
    <div class="modal fade" id="modalReporEstoque" tabindex="-1" aria-labelledby="modalReporEstoqueLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content rounded-4 border-0 shadow-lg">
                <div class="modal-header bg-success text-white rounded-top-4">
                    <h5 class="modal-title fw-bold" id="modalReporEstoqueLabel">
                        <i class="bi bi-box-arrow-in-down me-1"></i> Repor Estoque
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <form action="reporproduto.php" method="POST">
                    <input type="hidden" name="produto_id" id="repor_produto_id">
                    <div class="modal-body p-4">
                        <div class="p-3 bg-light rounded-3 mb-3 border">
                            <div class="text-muted small">Produto Selecionado:</div>
                            <div class="fs-6 fw-bold text-dark" id="repor_nome_display"></div>
                            <div class="text-muted small mt-1">
                                Estoque atual: <strong id="repor_qtd_display" class="text-dark"></strong>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-bold text-secondary">Quantidade a Adicionar *</label>
                            <input type="number" min="1" name="quantidade" class="form-control form-control-touch fs-5 fw-bold text-center" placeholder="Ex: 10" required autofocus>
                            <small class="text-muted">A quantidade será somada ao estoque atual e registrada nas movimentações.</small>
                        </div>
                    </div>
                    <div class="modal-footer bg-light rounded-bottom-4 p-3">
                        <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-success rounded-pill px-4 fw-bold">
                            <i class="bi bi-plus-lg"></i> Confirmar Entrada
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php renderScripts(1); ?>

    <script>
        function filtrarProdutosGerente() {
            const termo = document.getElementById('buscaProdutoInput').value.trim().toLowerCase();
            
            document.querySelectorAll('.card-produto-item').forEach(card => {
                const nome = card.getAttribute('data-nome') || '';
                const prat = card.getAttribute('data-prat') || '';
                if (nome.includes(termo) || prat.includes(termo)) {
                    card.classList.remove('d-none');
                } else {
                    card.classList.add('d-none');
                }
            });

            document.querySelectorAll('.linha-produto-item').forEach(linha => {
                const nome = linha.getAttribute('data-nome') || '';
                const prat = linha.getAttribute('data-prat') || '';
                if (nome.includes(termo) || prat.includes(termo)) {
                    linha.classList.remove('d-none');
                } else {
                    linha.classList.add('d-none');
                }
            });
        }

        function abrirModalEditar(p) {
            document.getElementById('edit_produto_id').value = p.id;
            document.getElementById('edit_nome').value = p.nome;
            document.getElementById('edit_preco').value = p.preco;
            document.getElementById('edit_estoque_minimo').value = p.estoque_minimo;
            document.getElementById('edit_prateleira').value = p.prateleira || '';
            
            const modal = new bootstrap.Modal(document.getElementById('modalEditarProduto'));
            modal.show();
        }

        function abrirModalRepor(p) {
            document.getElementById('repor_produto_id').value = p.id;
            document.getElementById('repor_nome_display').innerText = p.nome;
            document.getElementById('repor_qtd_display').innerText = p.quantidade + ' un';
            
            const modal = new bootstrap.Modal(document.getElementById('modalReporEstoque'));
            modal.show();
        }
    </script>
</body>
</html>
