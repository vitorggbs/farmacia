<?php
session_start();

require_once __DIR__ . '/../autenticacao.php';
require_once __DIR__ . '/conexaoDB.php';
require_once __DIR__ . '/../cabecalho.php';

exigirLogin('gerente');

$periodo = $_GET['periodo'] ?? 'dia';
$pagamento = $_GET['pagamento'] ?? '';
$farmaciaId = (int) $_SESSION['farmacia_id'];

$sql = "SELECT v.*, u.nome AS usuario_nome
        FROM vendas v
        INNER JOIN usuarios u ON u.id = v.usuario_id
        WHERE v.farmacia_id = ?";

$params = array($farmaciaId);
$types = 'i';

if ($periodo === 'dia') {
    $sql .= " AND DATE(v.data_venda) = CURDATE()";
}

$formas = array('dinheiro', 'pix', 'debito', 'credito');
if (in_array($pagamento, $formas)) {
    $sql .= " AND v.forma_pagamento = ?";
    $params[] = $pagamento;
    $types .= 's';
}

$sql .= " ORDER BY v.id DESC";

$stmt = mysqli_prepare($conexao, $sql);
mysqli_stmt_bind_param($stmt, $types, ...$params);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);

$vendas = array();
$totalFiltrado = 0;
while ($v = mysqli_fetch_assoc($resultado)) {
    $vendas[] = $v;
    $totalFiltrado += (float)$v['valor_total'];
}
mysqli_stmt_close($stmt);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <?php renderHead('FarmaCerta - Histórico de Recibos', 1); ?>
</head>
<body>
    <?php cabecalho('FarmaCerta - Gerente', 'gerente', 'recibos'); ?>

    <main class="container my-4 flex-grow-1">
        <!-- Filtros Card -->
        <div class="fc-card p-4 mb-4">
            <h1 class="h4 fw-bold text-dark mb-1 d-flex align-items-center gap-2">
                <i class="bi bi-receipt text-danger"></i> Histórico Geral de Vendas e Recibos
            </h1>
            <p class="text-muted small mb-3">Consulte todos os comprovantes emitidos por qualquer atendente da farmácia.</p>

            <form method="GET" class="row g-3 align-items-end">
                <div class="col-12 col-sm-6 col-md-4">
                    <label class="form-label small fw-bold text-secondary">Período de Venda</label>
                    <select name="periodo" class="form-select form-select-touch">
                        <option value="dia" <?= $periodo === 'dia' ? 'selected' : '' ?>>Vendas de Hoje</option>
                        <option value="todos" <?= $periodo === 'todos' ? 'selected' : '' ?>>Todo o Período</option>
                    </select>
                </div>

                <div class="col-12 col-sm-6 col-md-4">
                    <label class="form-label small fw-bold text-secondary">Forma de Pagamento</label>
                    <select name="pagamento" class="form-select form-select-touch">
                        <option value="">Todas as formas</option>
                        <?php foreach (array('dinheiro' => 'Dinheiro', 'pix' => 'Pix', 'debito' => 'Débito', 'credito' => 'Crédito') as $fKey => $fNome): ?>
                            <option value="<?= $fKey ?>" <?= $pagamento === $fKey ? 'selected' : '' ?>>
                                <?= $fNome ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-12 col-md-4 d-flex gap-2">
                    <button type="submit" class="btn btn-danger btn-touch flex-fill rounded-pill fw-bold">
                        <i class="bi bi-filter"></i> Filtrar Recibos
                    </button>
                    <a href="historicorecibogerente.php" class="btn btn-outline-secondary btn-touch rounded-pill px-3" title="Limpar">
                        <i class="bi bi-x-lg"></i>
                    </a>
                </div>
            </form>
        </div>

        <!-- Totalizador -->
        <div class="fc-card p-3 mb-4 bg-light border d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-2">
            <div>
                <span class="text-muted small text-uppercase fw-bold">Total no Período Selecionado:</span>
                <span class="fs-5 fw-bold text-success ms-2">R$ <?= number_format($totalFiltrado, 2, ',', '.') ?></span>
            </div>
            <span class="badge bg-secondary rounded-pill px-3 py-2"><?= count($vendas) ?> recibo(s) encontrado(s)</span>
        </div>

        <!-- Visão Mobile (Cards) -->
        <div class="d-md-none">
            <?php if (empty($vendas)): ?>
                <div class="fc-card p-4 text-center text-muted">
                    Nenhum recibo encontrado para os filtros selecionados.
                </div>
            <?php endif; ?>

            <?php foreach ($vendas as $v): ?>
                <div class="fc-card p-3 mb-3">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="badge bg-danger rounded-pill fw-bold">#<?= $v['id'] ?></span>
                        <span class="text-muted small"><?= date('d/m/Y H:i', strtotime($v['data_venda'])) ?></span>
                    </div>
                    <div class="fw-bold text-dark fs-6 mb-1">
                        <?= htmlspecialchars($v['cliente'] ?: 'Consumidor Final') ?>
                    </div>
                    <div class="text-muted small mb-2">
                        <i class="bi bi-person me-1"></i> Atendente: <?= htmlspecialchars($v['usuario_nome']) ?>
                    </div>
                    <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                        <div>
                            <span class="badge bg-light text-dark border text-uppercase me-2"><?= htmlspecialchars($v['forma_pagamento']) ?></span>
                            <span class="fw-bold text-success fs-6">R$ <?= number_format($v['valor_total'], 2, ',', '.') ?></span>
                        </div>
                        <a href="../balconista/recibobalconista.php?id=<?= $v['id'] ?>" class="btn btn-sm btn-outline-danger rounded-pill px-3 fw-bold">
                            <i class="bi bi-receipt"></i> Abrir
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Visão Desktop (Tabela) -->
        <div class="d-none d-md-block fc-card p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4">Número</th>
                            <th>Data/Hora</th>
                            <th>Cliente</th>
                            <th>Balconista</th>
                            <th>Forma de Pagamento</th>
                            <th>Valor Total</th>
                            <th class="text-end pe-4">Ação</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($vendas)): ?>
                            <tr>
                                <td colspan="7" class="text-center py-5 text-muted">
                                    Nenhum recibo encontrado no período.
                                </td>
                            </tr>
                        <?php endif; ?>

                        <?php foreach ($vendas as $v): ?>
                            <tr>
                                <td class="ps-4 fw-bold text-danger">#<?= $v['id'] ?></td>
                                <td><?= date('d/m/Y H:i', strtotime($v['data_venda'])) ?></td>
                                <td><?= htmlspecialchars($v['cliente'] ?: 'Consumidor Final') ?></td>
                                <td><i class="bi bi-person text-secondary me-1"></i><?= htmlspecialchars($v['usuario_nome']) ?></td>
                                <td>
                                    <span class="badge bg-light text-dark border text-uppercase px-2 py-1">
                                        <?= htmlspecialchars($v['forma_pagamento']) ?>
                                    </span>
                                </td>
                                <td class="fw-bold text-success">
                                    R$ <?= number_format($v['valor_total'], 2, ',', '.') ?>
                                </td>
                                <td class="text-end pe-4">
                                    <a href="../balconista/recibobalconista.php?id=<?= $v['id'] ?>" class="btn btn-sm btn-outline-danger rounded-pill px-3 fw-bold">
                                        <i class="bi bi-printer"></i> Ver Recibo
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <?php renderScripts(1); ?>
</body>
</html>
