<?php
session_start();

require_once __DIR__ . '/../autenticacao.php';
require_once __DIR__ . '/conexaoDB.php';
require_once __DIR__ . '/../cabecalho.php';

exigirLogin('gerente');

$farmaciaId = (int) $_SESSION['farmacia_id'];
$produtoId = isset($_GET['produto']) ? (int) $_GET['produto'] : 0;
$tipo = isset($_GET['tipo']) ? $_GET['tipo'] : '';
$periodo = isset($_GET['periodo']) ? $_GET['periodo'] : '30';

$tiposPermitidos = array('entrada', 'saida', 'ajuste');
$periodosPermitidos = array('hoje', '7', '30', 'todos');

if (!in_array($tipo, $tiposPermitidos)) {
    $tipo = '';
}

if (!in_array($periodo, $periodosPermitidos)) {
    $periodo = '30';
}

$sqlProdutos = 'SELECT id, nome FROM produtos WHERE farmacia_id = ? ORDER BY nome';
$stmtProdutos = mysqli_prepare($conexao, $sqlProdutos);
mysqli_stmt_bind_param($stmtProdutos, 'i', $farmaciaId);
mysqli_stmt_execute($stmtProdutos);
$resultadoProdutos = mysqli_stmt_get_result($stmtProdutos);

$produtos = array();
while ($produto = mysqli_fetch_assoc($resultadoProdutos)) {
    $produtos[] = $produto;
}
mysqli_stmt_close($stmtProdutos);

$sql = 'SELECT m.id,
               m.tipo,
               m.quantidade,
               m.observacao,
               m.criado_em,
               p.nome AS produto,
               u.nome AS usuario
        FROM movimentacoes_estoque m
        INNER JOIN produtos p ON p.id = m.produto_id
        INNER JOIN usuarios u ON u.id = m.usuario_id
        WHERE m.farmacia_id = ?';

$parametros = array($farmaciaId);
$tipos = 'i';

if ($produtoId > 0) {
    $sql .= ' AND m.produto_id = ?';
    $parametros[] = $produtoId;
    $tipos .= 'i';
}

if ($tipo != '') {
    $sql .= ' AND m.tipo = ?';
    $parametros[] = $tipo;
    $tipos .= 's';
}

if ($periodo == 'hoje') {
    $sql .= ' AND DATE(m.criado_em) = CURDATE()';
} elseif ($periodo == '7') {
    $sql .= ' AND m.criado_em >= DATE_SUB(NOW(), INTERVAL 7 DAY)';
} elseif ($periodo == '30') {
    $sql .= ' AND m.criado_em >= DATE_SUB(NOW(), INTERVAL 30 DAY)';
}

$sql .= ' ORDER BY m.id DESC';

$stmt = mysqli_prepare($conexao, $sql);
mysqli_stmt_bind_param($stmt, $tipos, ...$parametros);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);

$movimentacoes = array();
$totalEntradas = 0;
$totalSaidas = 0;
$totalAjustes = 0;

while ($movimentacao = mysqli_fetch_assoc($resultado)) {
    $movimentacoes[] = $movimentacao;

    if ($movimentacao['tipo'] == 'entrada') {
        $totalEntradas += (int) $movimentacao['quantidade'];
    } elseif ($movimentacao['tipo'] == 'saida') {
        $totalSaidas += (int) $movimentacao['quantidade'];
    } else {
        $totalAjustes += (int) $movimentacao['quantidade'];
    }
}
mysqli_stmt_close($stmt);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <?php renderHead('FarmaCerta - Movimentações de Estoque', 1); ?>
</head>
<body>
    <?php cabecalho('FarmaCerta - Gerente', 'gerente', 'movimentacoes'); ?>

    <main class="container my-4 flex-grow-1">
        <!-- Filtros Card -->
        <div class="fc-card p-4 mb-4">
            <h1 class="h4 fw-bold text-dark mb-1 d-flex align-items-center gap-2">
                <i class="bi bi-arrow-left-right text-danger"></i> Movimentações de Estoque
            </h1>
            <p class="text-muted small mb-3">Histórico auditável de entradas, saídas e ajustes de inventário.</p>

            <form method="GET" class="row g-3 align-items-end">
                <div class="col-12 col-md-4">
                    <label class="form-label small fw-bold text-secondary">Filtrar por Produto</label>
                    <select name="produto" class="form-select form-select-touch">
                        <option value="0">Todos os produtos</option>
                        <?php foreach ($produtos as $p): ?>
                            <option value="<?= $p['id'] ?>" <?= $produtoId == $p['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($p['nome']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-12 col-sm-6 col-md-3">
                    <label class="form-label small fw-bold text-secondary">Tipo de Movimento</label>
                    <select name="tipo" class="form-select form-select-touch">
                        <option value="">Todos os tipos</option>
                        <option value="entrada" <?= $tipo == 'entrada' ? 'selected' : '' ?>>📥 Entradas (+)</option>
                        <option value="saida" <?= $tipo == 'saida' ? 'selected' : '' ?>>📤 Saídas (-)</option>
                        <option value="ajuste" <?= $tipo == 'ajuste' ? 'selected' : '' ?>>⚙️ Ajustes</option>
                    </select>
                </div>

                <div class="col-12 col-sm-6 col-md-3">
                    <label class="form-label small fw-bold text-secondary">Período</label>
                    <select name="periodo" class="form-select form-select-touch">
                        <option value="hoje" <?= $periodo == 'hoje' ? 'selected' : '' ?>>Hoje</option>
                        <option value="7" <?= $periodo == '7' ? 'selected' : '' ?>>Últimos 7 dias</option>
                        <option value="30" <?= $periodo == '30' ? 'selected' : '' ?>>Últimos 30 dias</option>
                        <option value="todos" <?= $periodo == 'todos' ? 'selected' : '' ?>>Todo o período</option>
                    </select>
                </div>

                <div class="col-12 col-md-2 d-flex gap-2">
                    <button type="submit" class="btn btn-danger btn-touch flex-fill rounded-pill fw-bold">
                        <i class="bi bi-filter"></i> Filtrar
                    </button>
                    <a href="movimentacoesestoque.php" class="btn btn-outline-secondary btn-touch rounded-pill px-3" title="Limpar Filtros">
                        <i class="bi bi-x-lg"></i>
                    </a>
                </div>
            </form>
        </div>

        <!-- Badges Resumo -->
        <div class="row g-3 mb-4">
            <div class="col-6 col-lg-3">
                <div class="kpi-card h-100 p-3">
                    <div class="kpi-icon success" style="width: 44px; height: 44px; font-size: 1.25rem;">
                        <i class="bi bi-box-arrow-in-down"></i>
                    </div>
                    <div>
                        <div class="text-muted small text-uppercase">Entradas</div>
                        <div class="fs-4 fw-bold text-success">+<?= $totalEntradas ?> un</div>
                    </div>
                </div>
            </div>

            <div class="col-6 col-lg-3">
                <div class="kpi-card h-100 p-3">
                    <div class="kpi-icon primary" style="width: 44px; height: 44px; font-size: 1.25rem;">
                        <i class="bi bi-box-arrow-up"></i>
                    </div>
                    <div>
                        <div class="text-muted small text-uppercase">Saídas</div>
                        <div class="fs-4 fw-bold text-danger">-<?= $totalSaidas ?> un</div>
                    </div>
                </div>
            </div>

            <div class="col-6 col-lg-3">
                <div class="kpi-card h-100 p-3">
                    <div class="kpi-icon warning" style="width: 44px; height: 44px; font-size: 1.25rem;">
                        <i class="bi bi-sliders"></i>
                    </div>
                    <div>
                        <div class="text-muted small text-uppercase">Ajustes</div>
                        <div class="fs-4 fw-bold text-dark"><?= $totalAjustes ?> un</div>
                    </div>
                </div>
            </div>

            <div class="col-6 col-lg-3">
                <div class="kpi-card h-100 p-3">
                    <div class="kpi-icon info" style="width: 44px; height: 44px; font-size: 1.25rem;">
                        <i class="bi bi-list-check"></i>
                    </div>
                    <div>
                        <div class="text-muted small text-uppercase">Registros</div>
                        <div class="fs-4 fw-bold text-dark"><?= count($movimentacoes) ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Visão Mobile (Cards de Movimentação) -->
        <div class="d-md-none">
            <?php if (empty($movimentacoes)): ?>
                <div class="fc-card p-4 text-center text-muted">
                    Nenhuma movimentação encontrada com os filtros selecionados.
                </div>
            <?php endif; ?>

            <?php foreach ($movimentacoes as $m): 
                $corBadge = ($m['tipo'] === 'entrada') ? 'bg-success' : (($m['tipo'] === 'saida') ? 'bg-danger' : 'bg-warning text-dark');
                $sinal = ($m['tipo'] === 'entrada') ? '+' : (($m['tipo'] === 'saida') ? '-' : '');
            ?>
                <div class="fc-card p-3 mb-3">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="badge <?= $corBadge ?> rounded-pill text-uppercase px-3 py-1">
                            <?= $m['tipo'] ?> <?= $sinal ?><?= (int)$m['quantidade'] ?> un
                        </span>
                        <span class="text-muted small"><?= date('d/m/Y H:i', strtotime($m['criado_em'])) ?></span>
                    </div>
                    <div class="fw-bold text-dark fs-6 mb-1"><?= htmlspecialchars($m['produto']) ?></div>
                    <div class="d-flex justify-content-between text-muted small mt-2 pt-2 border-top">
                        <span><i class="bi bi-person me-1"></i> <?= htmlspecialchars($m['usuario']) ?></span>
                        <span><?= htmlspecialchars($m['observacao'] ?: 'Sem observação') ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Visão Desktop (Tabela) -->
        <div class="d-none d-md-block fc-card p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4">Data/Hora</th>
                            <th>Produto</th>
                            <th>Tipo</th>
                            <th class="text-center">Quantidade</th>
                            <th>Responsável</th>
                            <th class="pe-4">Observação</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($movimentacoes)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-5 text-muted">
                                    Nenhuma movimentação encontrada para os filtros selecionados.
                                </td>
                            </tr>
                        <?php endif; ?>

                        <?php foreach ($movimentacoes as $m): 
                            $corBadge = ($m['tipo'] === 'entrada') ? 'bg-success-subtle text-success border border-success' : (($m['tipo'] === 'saida') ? 'bg-danger-subtle text-danger border border-danger' : 'bg-warning-subtle text-dark border border-warning');
                            $sinal = ($m['tipo'] === 'entrada') ? '+' : (($m['tipo'] === 'saida') ? '-' : '');
                        ?>
                            <tr>
                                <td class="ps-4 text-muted small"><?= date('d/m/Y H:i', strtotime($m['criado_em'])) ?></td>
                                <td class="fw-bold text-dark"><?= htmlspecialchars($m['produto']) ?></td>
                                <td>
                                    <span class="badge <?= $corBadge ?> rounded-pill text-uppercase px-3 py-1">
                                        <?= $m['tipo'] ?>
                                    </span>
                                </td>
                                <td class="text-center fw-bold <?= $m['tipo'] === 'entrada' ? 'text-success' : ($m['tipo'] === 'saida' ? 'text-danger' : 'text-dark') ?>">
                                    <?= $sinal ?><?= (int)$m['quantidade'] ?> un
                                </td>
                                <td>
                                    <span class="text-secondary small">
                                        <i class="bi bi-person me-1"></i> <?= htmlspecialchars($m['usuario']) ?>
                                    </span>
                                </td>
                                <td class="pe-4 text-muted small"><?= htmlspecialchars($m['observacao'] ?: '—') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <?php renderScripts(1); ?>
</body>
</html>
