document.addEventListener("DOMContentLoaded", function() {
    initFarmaCertaSelects();
});

function initFarmaCertaSelects() {
    const selects = document.querySelectorAll("select.fc-custom-select, select.form-select-touch, select.form-select, select:not([multiple])");
    selects.forEach(select => {
        if (select.dataset.fcSelectInitialized) return;
        select.dataset.fcSelectInitialized = "true";
        select.style.display = "none";
        const wrapper = document.createElement("div");
        wrapper.className = "fc-custom-select-container";
        const trigger = document.createElement("button");
        trigger.type = "button";
        trigger.className = "fc-custom-select-trigger";
        const triggerText = document.createElement("span");
        triggerText.className = "fc-trigger-label text-truncate";
        const arrowSvg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        arrowSvg.setAttribute("class", "fc-select-arrow");
        arrowSvg.setAttribute("viewBox", "0 0 24 24");
        arrowSvg.innerHTML = '<path d="M7 10l5 5 5-5z"/>';
        trigger.appendChild(triggerText);
        trigger.appendChild(arrowSvg);
        const dropdownList = document.createElement("div");
        dropdownList.className = "fc-custom-select-list";
        function buildOptions() {
            dropdownList.innerHTML = "";
            let selectedOption = select.options[select.selectedIndex];
            if (!selectedOption && select.options.length > 0) {
                selectedOption = select.options[0];
            }
            triggerText.textContent = selectedOption ? selectedOption.text : "Selecione...";
            Array.from(select.options).forEach((opt, idx) => {
                if (opt.disabled && opt.value === "") return;
                const item = document.createElement("div");
                item.className = "fc-custom-select-item";
                if (opt.selected) {
                    item.classList.add("selected");
                }
                const check = document.createElement("span");
                check.className = "fc-check-icon";
                check.textContent = "✓";
                const label = document.createElement("span");
                label.className = "fc-item-label";
                label.textContent = opt.text;
                item.appendChild(check);
                item.appendChild(label);
                item.addEventListener("click", (e) => {
                    e.stopPropagation();
                    select.value = opt.value;
                    select.selectedIndex = idx;
                    select.dispatchEvent(new Event("change", { bubbles: true }));
                    updateVisual();
                    closeAllSelects();
                });
                dropdownList.appendChild(item);
            });
        }
        function updateVisual() {
            const currentSelected = select.options[select.selectedIndex];
            triggerText.textContent = currentSelected ? currentSelected.text : "Selecione...";
            const items = dropdownList.querySelectorAll(".fc-custom-select-item");
            let itemIdx = 0;
            Array.from(select.options).forEach((opt) => {
                if (opt.disabled && opt.value === "") return;
                if (items[itemIdx]) {
                    if (opt.selected) {
                        items[itemIdx].classList.add("selected");
                    } else {
                        items[itemIdx].classList.remove("selected");
                    }
                }
                itemIdx++;
            });
        }
        buildOptions();
        trigger.addEventListener("click", function(e) {
            e.stopPropagation();
            const isOpen = wrapper.classList.contains("open");
            closeAllSelects();
            if (!isOpen) {
                wrapper.classList.add("open");
                trigger.classList.add("active");
            }
        });
        select.addEventListener("change", function() {
            updateVisual();
        });
        wrapper.appendChild(trigger);
        wrapper.appendChild(dropdownList);
        select.parentNode.insertBefore(wrapper, select);
        wrapper.appendChild(select);
    });
}

function closeAllSelects() {
    document.querySelectorAll(".fc-custom-select-container").forEach(el => {
        el.classList.remove("open");
        const trigger = el.querySelector(".fc-custom-select-trigger");
        if (trigger) trigger.classList.remove("active");
    });
}

document.addEventListener("click", function() {
    closeAllSelects();
});

document.addEventListener("keydown", function(e) {
    if (e.key === "Escape") {
        closeAllSelects();
    }
});