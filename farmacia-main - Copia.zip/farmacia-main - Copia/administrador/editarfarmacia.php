<?php
session_start();

require_once __DIR__ . '/../autenticacao.php';
require_once __DIR__ . '/../gerente/conexaoDB.php';
require_once __DIR__ . '/cabecalhoadmin.php';

exigirAdministrador();

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);

if ($id <= 0) {
    header('Location: farmacias.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $cnpj = trim($_POST['cnpj'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');
    $endereco = trim($_POST['endereco'] ?? '');

    if ($nome == '') {
        header('Location: editarfarmacia.php?id=' . $id . '&erro=1');
        exit;
    }

    $sql = 'UPDATE farmacias SET nome = ?, cnpj = ?, telefone = ?, endereco = ? WHERE id = ?';
    $stmt = mysqli_prepare($conexao, $sql);
    mysqli_stmt_bind_param($stmt, 'ssssi', $nome, $cnpj, $telefone, $endereco, $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header('Location: farmacias.php?ok=1');
    exit;
}

$sql = 'SELECT * FROM farmacias WHERE id = ?';
$stmt = mysqli_prepare($conexao, $sql);
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);
$farmacia = mysqli_fetch_assoc($resultado);
mysqli_stmt_close($stmt);

if (!$farmacia) {
    header('Location: farmacias.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <?php renderHeadAdmin('FarmaCerta - Editar Farmácia'); ?>
</head>
<body>
    <?php cabecalhoAdmin('FarmaCerta - Editar Farmácia', 'farmacias'); ?>

    <main class="container my-4 flex-grow-1" style="max-width: 720px;">
        <div class="fc-card p-4">
            <div class="d-flex align-items-center justify-content-between pb-3 border-bottom mb-4">
                <h1 class="h4 fw-bold text-dark mb-0 d-flex align-items-center gap-2">
                    <i class="bi bi-pencil-square text-danger"></i> Editar Dados da Farmácia
                </h1>
                <a href="farmacias.php" class="btn btn-outline-secondary rounded-pill px-3 py-1 small fw-semibold">
                    <i class="bi bi-arrow-left"></i> Voltar
                </a>
            </div>

            <?php if (isset($_GET['erro'])): ?>
                <div class="alert alert-danger alert-dismissible fade show rounded-3 shadow-sm mb-4" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    O nome da farmácia é obrigatório.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <form action="editarfarmacia.php" method="POST">
                <input type="hidden" name="id" value="<?= $farmacia['id'] ?>">

                <div class="mb-3">
                    <label class="form-label small fw-bold text-secondary">Nome da Farmácia / Razão Social *</label>
                    <input type="text" name="nome" class="form-control form-control-touch" value="<?= htmlspecialchars($farmacia['nome']) ?>" required autofocus>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-bold text-secondary">CNPJ</label>
                        <input type="text" name="cnpj" class="form-control form-control-touch" value="<?= htmlspecialchars($farmacia['cnpj'] ?? '') ?>" placeholder="00.000.000/0000-00">
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-bold text-secondary">Telefone</label>
                        <input type="text" name="telefone" class="form-control form-control-touch" value="<?= htmlspecialchars($farmacia['telefone'] ?? '') ?>" placeholder="(00) 0000-0000">
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label small fw-bold text-secondary">Endereço Completo</label>
                    <textarea name="endereco" rows="3" class="form-control form-control-touch" placeholder="Rua, Número, Bairro, Cidade - UF"><?= htmlspecialchars($farmacia['endereco'] ?? '') ?></textarea>
                </div>

                <div class="d-flex justify-content-end gap-2 pt-3 border-top">
                    <a href="farmacias.php" class="btn btn-outline-secondary rounded-pill px-4">Cancelar</a>
                    <button type="submit" class="btn btn-danger rounded-pill px-4 fw-bold">
                        <i class="bi bi-check2"></i> Salvar Alterações
                    </button>
                </div>
            </form>
        </div>
    </main>

    <?php renderScriptsAdmin(); ?>
</body>
</html>
