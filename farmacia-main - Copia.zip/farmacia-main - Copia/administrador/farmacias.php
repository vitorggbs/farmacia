<?php
session_start();

require_once __DIR__ . '/../autenticacao.php';
require_once __DIR__ . '/../gerente/conexaoDB.php';
require_once __DIR__ . '/cabecalhoadmin.php';

exigirAdministrador();

$sql = "SELECT
            f.id,
            f.nome,
            f.cnpj,
            f.telefone,
            f.endereco,
            f.ativo,
            COUNT(u.id) AS usuarios,
            SUM(u.cargo = 'gerente' AND u.ativo = 1) AS gerentes
        FROM farmacias f
        LEFT JOIN usuarios u ON u.farmacia_id = f.id
        GROUP BY f.id
        ORDER BY f.id DESC";

$farmacias = mysqli_query($conexao, $sql);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <?php renderHeadAdmin('FarmaCerta - Gestão de Farmácias'); ?>
</head>
<body>
    <?php cabecalhoAdmin('FarmaCerta - Farmácias', 'farmacias'); ?>

    <main class="container my-4 flex-grow-1">
        <!-- Topo & Botão Cadastro -->
        <div class="fc-card p-4 mb-4">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
                <div>
                    <h1 class="h4 fw-bold text-dark mb-1">
                        <i class="bi bi-building text-danger me-1"></i> Unidades Farmacêuticas
                    </h1>
                    <p class="text-muted small mb-0">Cadastre novas lojas e gerencie o status de funcionamento de cada filial.</p>
                </div>
                <div>
                    <button class="btn btn-danger btn-touch rounded-pill px-4 fw-bold shadow-sm" data-bs-toggle="collapse" data-bs-target="#collapseCadastrarFarmacia" aria-expanded="false" aria-controls="collapseCadastrarFarmacia">
                        <i class="bi bi-plus-circle-fill fs-5"></i>
                        <span>NOVA FARMÁCIA</span>
                    </button>
                </div>
            </div>

            <!-- Formulário de Cadastro (Collapse) -->
            <div class="collapse <?= isset($_GET['erro']) ? 'show' : '' ?>" id="collapseCadastrarFarmacia">
                <div class="p-4 bg-light rounded-4 border mt-4">
                    <h2 class="h5 fw-bold text-dark mb-3">
                        <i class="bi bi-building-add text-danger"></i> Formulário de Nova Unidade & Gerente Inicial
                    </h2>

                    <?php if (isset($_GET['erro'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show rounded-3 shadow-sm mb-3" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i>
                            Preencha todos os campos obrigatórios corretamente.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <form action="cadastrarfarmacia.php" method="POST">
                        <h3 class="h6 fw-bold text-secondary text-uppercase mb-3">1. Dados da Farmácia</h3>
                        <div class="row g-3 mb-4">
                            <div class="col-12 col-md-6">
                                <label class="form-label small fw-bold text-secondary">Nome da Farmácia / Razão Social *</label>
                                <input type="text" name="nome" class="form-control form-control-touch" placeholder="Ex: Farmácia Central" required>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label small fw-bold text-secondary">CNPJ</label>
                                <input type="text" name="cnpj" class="form-control form-control-touch" placeholder="00.000.000/0000-00">
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label small fw-bold text-secondary">Telefone de Contato</label>
                                <input type="text" name="telefone" class="form-control form-control-touch" placeholder="(00) 0000-0000">
                            </div>
                            <div class="col-12 col-md-8">
                                <label class="form-label small fw-bold text-secondary">Endereço Completo</label>
                                <input type="text" name="endereco" class="form-control form-control-touch" placeholder="Rua, Número, Bairro, Cidade - UF">
                            </div>
                        </div>

                        <h3 class="h6 fw-bold text-secondary text-uppercase mb-3 pt-3 border-top">2. Primeiro Gerente Responsável</h3>
                        <div class="row g-3 mb-4">
                            <div class="col-12 col-md-6">
                                <label class="form-label small fw-bold text-secondary">Nome do Gerente *</label>
                                <input type="text" name="gerente_nome" class="form-control form-control-touch" placeholder="Ex: Marcos Souza" required>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label small fw-bold text-secondary">CPF do Gerente</label>
                                <input type="text" name="gerente_cpf" class="form-control form-control-touch" placeholder="000.000.000-00">
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label small fw-bold text-secondary">Login de Acesso do Gerente *</label>
                                <input type="text" name="gerente_login" class="form-control form-control-touch" placeholder="Ex: gerente.loja1" required>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label small fw-bold text-secondary">Senha de Acesso (Mínimo 6 dígitos) *</label>
                                <input type="password" name="gerente_senha" class="form-control form-control-touch" placeholder="******" minlength="6" required>
                            </div>
                        </div>

                        <div class="d-flex justify-content-end gap-2 pt-3 border-top">
                            <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-toggle="collapse" data-bs-target="#collapseCadastrarFarmacia">
                                Cancelar
                            </button>
                            <button type="submit" class="btn btn-danger rounded-pill px-4 fw-bold">
                                <i class="bi bi-check2"></i> Salvar e Ativar Farmácia
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Feedback Success -->
        <?php if (isset($_GET['ok'])): ?>
            <div class="alert alert-success alert-dismissible fade show rounded-3 shadow-sm d-flex align-items-center gap-2 mb-4" role="alert">
                <i class="bi bi-check-circle-fill fs-5"></i>
                <div>Operação realizada com sucesso!</div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Visão Mobile (Cards) -->
        <div class="d-md-none">
            <?php mysqli_data_seek($farmacias, 0); ?>
            <?php while ($f = mysqli_fetch_assoc($farmacias)): 
                $ativa = (int)$f['ativo'] === 1;
            ?>
                <div class="fc-card p-3 mb-3 <?= !$ativa ? 'opacity-75 bg-light' : '' ?>">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="badge <?= $ativa ? 'bg-success' : 'bg-secondary' ?> rounded-pill">
                            <?= $ativa ? 'Ativa' : 'Desativada' ?>
                        </span>
                        <span class="text-muted small"><?= (int)$f['usuarios'] ?> usuário(s)</span>
                    </div>
                    <h2 class="h6 fw-bold text-dark mb-1"><?= htmlspecialchars($f['nome']) ?></h2>
                    <div class="text-muted small mb-3">
                        <div><i class="bi bi-geo-alt me-1"></i> <?= htmlspecialchars($f['endereco'] ?: 'Endereço não informado') ?></div>
                        <div><i class="bi bi-card-text me-1"></i> CNPJ: <?= htmlspecialchars($f['cnpj'] ?: '—') ?></div>
                    </div>
                    <div class="d-flex gap-2 pt-2 border-top">
                        <a href="editarfarmacia.php?id=<?= $f['id'] ?>" class="btn btn-sm btn-outline-primary flex-fill rounded-pill fw-bold">
                            <i class="bi bi-pencil"></i> Editar
                        </a>
                        <a 
                            href="alterarstatus.php?id=<?= $f['id'] ?>" 
                            class="btn btn-sm <?= $ativa ? 'btn-outline-danger' : 'btn-outline-success' ?> flex-fill rounded-pill fw-bold"
                            onclick="return confirm('Deseja <?= $ativa ? 'desativar' : 'reativar' ?> esta farmácia?');"
                        >
                            <i class="bi <?= $ativa ? 'bi-lock' : 'bi-unlock' ?>"></i>
                            <?= $ativa ? 'Desativar' : 'Reativar' ?>
                        </a>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>

        <!-- Visão Desktop (Tabela) -->
        <div class="d-none d-md-block fc-card p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4">Farmácia</th>
                            <th>CNPJ</th>
                            <th>Telefone</th>
                            <th>Endereço</th>
                            <th>Usuários</th>
                            <th>Status</th>
                            <th class="text-end pe-4" style="width: 220px;">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php mysqli_data_seek($farmacias, 0); ?>
                        <?php while ($f = mysqli_fetch_assoc($farmacias)): 
                            $ativa = (int)$f['ativo'] === 1;
                        ?>
                            <tr class="<?= !$ativa ? 'opacity-75 bg-light' : '' ?>">
                                <td class="ps-4 fw-bold text-dark"><?= htmlspecialchars($f['nome']) ?></td>
                                <td><?= htmlspecialchars($f['cnpj'] ?: '—') ?></td>
                                <td><?= htmlspecialchars($f['telefone'] ?: '—') ?></td>
                                <td class="small text-muted"><?= htmlspecialchars($f['endereco'] ?: '—') ?></td>
                                <td>
                                    <span class="badge bg-light text-dark border rounded-pill px-2 py-1">
                                        <?= (int)$f['usuarios'] ?> usuário(s)
                                    </span>
                                </td>
                                <td>
                                    <span class="badge <?= $ativa ? 'bg-success-subtle text-success border border-success' : 'bg-secondary-subtle text-secondary border border-secondary' ?> rounded-pill px-3 py-1">
                                        <?= $ativa ? 'Ativa' : 'Inativa' ?>
                                    </span>
                                </td>
                                <td class="text-end pe-4">
                                    <a href="editarfarmacia.php?id=<?= $f['id'] ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-bold me-1">
                                        <i class="bi bi-pencil"></i> Editar
                                    </a>
                                    <a 
                                        href="alterarstatus.php?id=<?= $f['id'] ?>" 
                                        class="btn btn-sm <?= $ativa ? 'btn-outline-danger' : 'btn-outline-success' ?> rounded-pill px-3 fw-bold"
                                        onclick="return confirm('Deseja <?= $ativa ? 'desativar' : 'reativar' ?> esta farmácia?');"
                                    >
                                        <i class="bi <?= $ativa ? 'bi-lock' : 'bi-unlock' ?>"></i>
                                        <?= $ativa ? 'Desativar' : 'Ativar' ?>
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <?php renderScriptsAdmin(); ?>
</body>
</html>
