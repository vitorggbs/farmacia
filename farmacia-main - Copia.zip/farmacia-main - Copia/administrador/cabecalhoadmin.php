<?php

if (!function_exists('renderHeadAdmin')) {
    function renderHeadAdmin($titulo) {
        $cssTime = file_exists(__DIR__ . '/../style.css') ? filemtime(__DIR__ . '/../style.css') : time();
        echo '
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
        <title>' . htmlspecialchars($titulo, ENT_QUOTES, 'UTF-8') . '</title>
        <link rel="icon" type="image/png" href="../assets/LOGO_2.png">
        <!-- Bootstrap 5.3.3 CSS -->
        <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
        <!-- Bootstrap Icons -->
        <link rel="stylesheet" href="../assets/vendor/bootstrap-icons/bootstrap-icons.min.css">
        <!-- FarmaCerta Design System -->
        <link rel="stylesheet" href="../style.css?v=' . $cssTime . '">
        ';
    }
}

if (!function_exists('renderScriptsAdmin')) {
    function renderScriptsAdmin() {
        echo '
        <!-- Bootstrap 5.3.3 JS Bundle -->
        <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="../assets/js/fc-select.js"></script>
        ';
    }
}

function cabecalhoAdmin($titulo, $paginaAtiva = '')
{
    $nomeUsuario = htmlspecialchars($_SESSION['admin_nome'] ?? 'Administrador', ENT_QUOTES, 'UTF-8');
    ?>
    <header class="fc-navbar">
        <div class="container-fluid d-flex align-items-center justify-content-between">
            <!-- Brand Logo -->
            <a href="inicioadmin.php" class="d-flex align-items-center text-decoration-none me-3" title="Início FarmaCerta">
                <img src="../assets/LOGO_1.png" alt="FarmaCerta" class="fc-brand-img">
            </a>

            <!-- Desktop Nav Items -->
            <nav class="d-none d-lg-flex align-items-center gap-2">
                <a href="inicioadmin.php" class="fc-nav-link <?= $paginaAtiva === 'inicio' ? 'active' : '' ?>">
                    <i class="bi bi-shield-check"></i> Painel Geral
                </a>
                <a href="farmacias.php" class="fc-nav-link <?= $paginaAtiva === 'farmacias' ? 'active' : '' ?>">
                    <i class="bi bi-building"></i> Farmácias
                </a>
            </nav>

            <!-- User Info & Actions -->
            <div class="d-flex align-items-center gap-2">
                <div class="fc-user-badge d-none d-sm-inline-flex">
                    <i class="bi bi-shield-lock-fill text-warning"></i>
                    <strong><?= $nomeUsuario ?></strong>
                    <span class="opacity-50">|</span>
                    <span>Admin Central</span>
                </div>

                <a class="fc-btn-logout d-none d-sm-inline-flex" href="../logout.php" title="Encerrar Sessão">
                    <i class="bi bi-box-arrow-right"></i> Sair
                </a>

                <!-- Hamburger Mobile Toggle -->
                <button class="btn btn-outline-light d-lg-none rounded-pill px-3 py-2 border-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#fcAdminMobileMenu" aria-controls="fcAdminMobileMenu" aria-label="Abrir Menu">
                    <i class="bi bi-list fs-5"></i>
                </button>
            </div>
        </div>
    </header>

    <!-- Offcanvas Menu Mobile -->
    <div class="offcanvas offcanvas-end fc-offcanvas" tabindex="-1" id="fcAdminMobileMenu" aria-labelledby="fcAdminMobileMenuLabel">
        <div class="offcanvas-header bg-danger text-white">
            <div class="d-flex align-items-center gap-2">
                <img src="../assets/LOGO_2.png" alt="Logo" width="32" height="32">
                <h5 class="offcanvas-title fw-bold mb-0" id="fcAdminMobileMenuLabel">FarmaCerta Admin</h5>
            </div>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Fechar"></button>
        </div>
        <div class="offcanvas-body d-flex flex-column justify-content-between p-3">
            <div>
                <div class="p-3 mb-3 bg-light rounded-3 border">
                    <div class="d-flex align-items-center gap-2 text-secondary mb-1">
                        <i class="bi bi-shield-lock text-danger"></i>
                        <span class="fw-bold text-dark">Administrador Central</span>
                    </div>
                    <div class="d-flex align-items-center gap-2 text-muted small">
                        <span><?= $nomeUsuario ?></span>
                    </div>
                </div>

                <nav class="nav flex-column gap-2">
                    <a href="inicioadmin.php" class="fc-nav-link <?= $paginaAtiva === 'inicio' ? 'active' : '' ?>">
                        <i class="bi bi-shield-check"></i> Painel Geral
                    </a>
                    <a href="farmacias.php" class="fc-nav-link <?= $paginaAtiva === 'farmacias' ? 'active' : '' ?>">
                        <i class="bi bi-building"></i> Farmácias Cadastradas
                    </a>
                </nav>
            </div>

            <div class="pt-3 border-top mt-4">
                <a class="btn btn-outline-danger w-100 rounded-pill py-2 fw-bold d-flex align-items-center justify-content-center gap-2" href="../logout.php">
                    <i class="bi bi-box-arrow-right"></i> Sair do Sistema
                </a>
            </div>
        </div>
    </div>
    <?php
}
