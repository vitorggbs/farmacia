<?php
session_start();

require_once __DIR__ . '/../autenticacao.php';
require_once __DIR__ . '/../gerente/conexaoDB.php';
require_once __DIR__ . '/cabecalhoadmin.php';

exigirAdministrador();

$resumo = mysqli_query($conexao, "SELECT
    COUNT(*) AS total,
    SUM(ativo = 1) AS ativas,
    SUM(ativo = 0) AS inativas
    FROM farmacias");
$dados = mysqli_fetch_assoc($resumo);

$usuarios = mysqli_query($conexao, "SELECT COUNT(*) AS total FROM usuarios WHERE ativo = 1");
$totalUsuarios = mysqli_fetch_assoc($usuarios)['total'] ?? 0;

$vendas = mysqli_query($conexao, "SELECT COALESCE(SUM(valor_total), 0) AS total, COUNT(*) AS qtd FROM vendas");
$dadosVendas = mysqli_fetch_assoc($vendas);
$totalVendas = (float)($dadosVendas['total'] ?? 0.0);
$qtdVendas = (int)($dadosVendas['qtd'] ?? 0);

$ultimas = mysqli_query(
    $conexao,
    "SELECT id, nome, cnpj, telefone, ativo, criado_em
     FROM farmacias
     ORDER BY id DESC
     LIMIT 8"
);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <?php renderHeadAdmin('FarmaCerta - Painel do Administrador'); ?>
</head>
<body>
    <?php cabecalhoAdmin('FarmaCerta - Administrador', 'inicio'); ?>

    <main class="container my-4 flex-grow-1">
        <!-- Boas-vindas -->
        <div class="fc-card p-4 mb-4 border-0">
            <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">
                <div>
                    <span class="badge bg-danger-subtle text-danger px-3 py-2 rounded-pill fw-bold mb-2">
                        <i class="bi bi-shield-lock-fill me-1"></i> Administração Geral do FarmaCerta ERP
                    </span>
                    <h1 class="h3 fw-bold mb-1 text-dark">Painel de Controle Central</h1>
                    <p class="text-muted mb-0">Gerencie todas as unidades farmacêuticas, acessos e faturamento global.</p>
                </div>
                <div>
                    <a href="farmacias.php" class="btn btn-danger btn-touch px-4 rounded-pill fw-bold shadow-sm">
                        <i class="bi bi-building-add"></i> Gerenciar Farmácias
                    </a>
                </div>
            </div>
        </div>

        <!-- KPIs Globais -->
        <div class="row g-3 mb-4">
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="kpi-card h-100">
                    <div class="kpi-icon primary">
                        <i class="bi bi-building"></i>
                    </div>
                    <div>
                        <div class="text-muted small text-uppercase fw-bold">Total de Farmácias</div>
                        <div class="fs-3 fw-bold text-dark"><?= (int)$dados['total'] ?></div>
                        <small class="text-success fw-semibold"><?= (int)$dados['ativas'] ?> ativas no sistema</small>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-xl-3">
                <div class="kpi-card h-100">
                    <div class="kpi-icon info">
                        <i class="bi bi-people-fill"></i>
                    </div>
                    <div>
                        <div class="text-muted small text-uppercase fw-bold">Usuários Ativos</div>
                        <div class="fs-3 fw-bold text-dark"><?= (int)$totalUsuarios ?></div>
                        <small class="text-secondary">Gerentes e balconistas</small>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-xl-3">
                <div class="kpi-card h-100">
                    <div class="kpi-icon success">
                        <i class="bi bi-cash-stack"></i>
                    </div>
                    <div>
                        <div class="text-muted small text-uppercase fw-bold">Faturamento Global</div>
                        <div class="fs-4 fw-bold text-success">R$ <?= number_format($totalVendas, 2, ',', '.') ?></div>
                        <small class="text-secondary">Todas as unidades</small>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-xl-3">
                <div class="kpi-card h-100">
                    <div class="kpi-icon warning">
                        <i class="bi bi-receipt-cutoff"></i>
                    </div>
                    <div>
                        <div class="text-muted small text-uppercase fw-bold">Total de Atendimentos</div>
                        <div class="fs-3 fw-bold text-dark"><?= (int)$qtdVendas ?></div>
                        <small class="text-secondary">Vendas processadas</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Lista de Farmácias Recentes -->
        <div class="fc-card p-0">
            <div class="p-4 border-bottom d-flex justify-content-between align-items-center">
                <h2 class="h5 fw-bold text-dark mb-0 d-flex align-items-center gap-2">
                    <i class="bi bi-shop text-danger"></i> Farmácias Cadastradas Recentemente
                </h2>
                <a href="farmacias.php" class="btn btn-sm btn-outline-danger rounded-pill px-3">
                    Ver Todas
                </a>
            </div>

            <!-- Visão Mobile (Cards) -->
            <div class="d-md-none p-3">
                <?php mysqli_data_seek($ultimas, 0); ?>
                <?php while ($f = mysqli_fetch_assoc($ultimas)): 
                    $ativa = (int)$f['ativo'] === 1;
                ?>
                    <div class="fc-card p-3 mb-3 border <?= !$ativa ? 'opacity-75 bg-light' : '' ?>">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="badge <?= $ativa ? 'bg-success' : 'bg-secondary' ?> rounded-pill">
                                <?= $ativa ? 'Ativa' : 'Inativa' ?>
                            </span>
                            <span class="text-muted small"><?= date('d/m/Y', strtotime($f['criado_em'])) ?></span>
                        </div>
                        <h3 class="h6 fw-bold text-dark mb-1"><?= htmlspecialchars($f['nome']) ?></h3>
                        <div class="text-muted small mb-2">
                            <div><i class="bi bi-card-text me-1"></i> CNPJ: <?= htmlspecialchars($f['cnpj'] ?: '—') ?></div>
                            <div><i class="bi bi-telephone me-1"></i> <?= htmlspecialchars($f['telefone'] ?: '—') ?></div>
                        </div>
                        <div class="pt-2 border-top">
                            <a href="editarfarmacia.php?id=<?= $f['id'] ?>" class="btn btn-sm btn-outline-primary rounded-pill w-100 fw-bold">
                                <i class="bi bi-pencil"></i> Editar Farmácia
                            </a>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>

            <!-- Visão Desktop (Tabela) -->
            <div class="d-none d-md-block">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Nome da Unidade</th>
                                <th>CNPJ</th>
                                <th>Telefone</th>
                                <th>Data de Cadastro</th>
                                <th>Status</th>
                                <th class="text-end pe-4">Ação</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php mysqli_data_seek($ultimas, 0); ?>
                            <?php while ($f = mysqli_fetch_assoc($ultimas)): 
                                $ativa = (int)$f['ativo'] === 1;
                            ?>
                                <tr class="<?= !$ativa ? 'opacity-75 bg-light' : '' ?>">
                                    <td class="ps-4 fw-bold text-dark"><?= htmlspecialchars($f['nome']) ?></td>
                                    <td><?= htmlspecialchars($f['cnpj'] ?: '—') ?></td>
                                    <td><?= htmlspecialchars($f['telefone'] ?: '—') ?></td>
                                    <td class="text-muted small"><?= date('d/m/Y', strtotime($f['criado_em'])) ?></td>
                                    <td>
                                        <span class="badge <?= $ativa ? 'bg-success-subtle text-success border border-success' : 'bg-secondary-subtle text-secondary border border-secondary' ?> rounded-pill px-3 py-1">
                                            <?= $ativa ? 'Ativa' : 'Inativa' ?>
                                        </span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <a href="editarfarmacia.php?id=<?= $f['id'] ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-bold">
                                            <i class="bi bi-pencil"></i> Editar
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <?php renderScriptsAdmin(); ?>
</body>
</html>
