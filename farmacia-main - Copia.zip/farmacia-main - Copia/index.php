<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <title>FarmaCerta - Login</title>
    <link rel="icon" type="image/png" href="assets/LOGO_2.png">
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css?v=<?= file_exists(__DIR__ . '/style.css') ? filemtime(__DIR__ . '/style.css') : time() ?>">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        .login-card {
            background: #d62828;
            border-radius: 24px;
            padding: 44px 38px;
            width: 100%;
            max-width: 420px;
        }
        .logo-title {
            color: #ffffff;
            font-size: 38px;
            font-weight: 800;
            text-align: center;
            letter-spacing: -0.5px;
            margin-bottom: 20px;
        }
        .logo-image-container {
            text-align: center;
            margin-bottom: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .logo-image {
            max-width: 110px;
            height: auto;
            object-fit: contain;
        }
        label.field-label {
            color: #ffffff;
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 0.8px;
            text-transform: uppercase;
            display: block;
            margin-bottom: 8px;
        }
        .clean-input {
            width: 100%;
            height: 50px;
            padding: 0 20px;
            border: none;
            border-radius: 50px;
            font-size: 15px;
            color: #333333;
            background: #ffffff;
            outline: none;
            margin-bottom: 20px;
        }
        .clean-input::placeholder { color: #888888; }
        .divider {
            height: 1px;
            background: rgba(255, 255, 255, 0.2);
            margin: 22px 0;
        }
        .btn-entrar {
            width: 100%;
            height: 50px;
            border: none;
            border-radius: 50px;
            font-size: 15px;
            font-weight: 700;
            color: #ffffff;
            background: rgba(255, 255, 255, 0.22);
            cursor: pointer;
            transition: background 0.2s ease;
            letter-spacing: 0.8px;
            text-transform: uppercase;
        }
        .btn-entrar:hover { background: rgba(255, 255, 255, 0.32); }
    </style>
</head>
<body>
    <main class="login-card">
        <h1 class="logo-title">FarmaCerta</h1>
        <div class="logo-image-container">
            <img src="assets/LOGO_2.png" alt="Logo FarmaCerta" class="logo-image">
        </div>
        <?php if (isset($_GET['erro']) && $_GET['erro'] === 'login'): ?>
            <div class="alert alert-light border-0 py-2 px-3 mb-3 rounded-3 text-danger fw-bold text-center small" role="alert">
                Usuário, senha ou cargo inválidos.
            </div>
        <?php endif; ?>
        <form action="login.php" method="POST">
            <label class="field-label">LOGIN</label>
            <input type="text" name="login" class="clean-input" required placeholder="Digite seu login">
            <label class="field-label">SENHA</label>
            <input type="password" name="senha" class="clean-input" required placeholder="Digite sua senha">
            <label class="field-label">ENTRAR COMO</label>
            <div class="mb-3">
                <select name="cargo" class="fc-custom-select" required>
                    <option value="administrador" selected>Administrador</option>
                    <option value="gerente">Gerente</option>
                    <option value="balconista">Balconista</option>
                </select>
            </div>
            <div class="divider"></div>
            <button type="submit" class="btn-entrar">ENTRAR</button>
        </form>
    </main>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/fc-select.js"></script>
</body>
</html>