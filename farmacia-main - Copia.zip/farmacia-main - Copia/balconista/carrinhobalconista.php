<?php
session_start();

require_once __DIR__ . '/../autenticacao.php';
require_once __DIR__ . '/../gerente/conexaoDB.php';
require_once __DIR__ . '/../cabecalho.php';

exigirLogin('balconista');

if (!isset($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = array();
}

$farmaciaId = (int) $_SESSION['farmacia_id'];
$carrinho = $_SESSION['carrinho'];
$produtosCarrinho = array();
$total = 0;

foreach ($carrinho as $produto_id => $quantidade) {
    $produto_id = (int) $produto_id;
    $quantidade = (int) $quantidade;

    $stmt = mysqli_prepare(
        $conexao,
        "SELECT id, nome, preco, quantidade, imagem FROM produtos WHERE id = ? AND farmacia_id = ?"
    );
    mysqli_stmt_bind_param($stmt, 'ii', $produto_id, $farmaciaId);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $id, $nome, $preco, $estoque, $imagem);

    if (mysqli_stmt_fetch($stmt)) {
        $subtotal = (float) $preco * $quantidade;
        $total += $subtotal;

        $produtosCarrinho[] = array(
            'id' => $id,
            'nome' => $nome,
            'preco' => (float)$preco,
            'quantidade' => $quantidade,
            'estoque' => (int)$estoque,
            'imagem' => $imagem,
            'subtotal' => $subtotal
        );
    }
    mysqli_stmt_close($stmt);
}

$quantidadeCarrinho = array_sum($carrinho);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <?php renderHead('FarmaCerta - Carrinho', 1); ?>
</head>
<body>
    <?php cabecalho('FarmaCerta - Balconista', 'balconista', 'carrinho'); ?>

    <main class="container my-4 flex-grow-1">
        <div class="d-flex align-items-center justify-content-between mb-4">
            <div>
                <h1 class="h3 fw-bold text-dark mb-1">
                    <i class="bi bi-cart3 text-danger me-1"></i> Carrinho de Compras
                </h1>
                <p class="text-muted small mb-0">Revise os itens antes de fechar o atendimento.</p>
            </div>
            <a href="produtosbalconista.php" class="btn btn-outline-secondary rounded-pill px-3 py-2 fw-semibold d-inline-flex align-items-center gap-1">
                <i class="bi bi-arrow-left"></i> Continuar Comprando
            </a>
        </div>

        <?php if (isset($_GET['erro'])): ?>
            <div class="alert alert-danger alert-dismissible fade show rounded-3 shadow-sm d-flex align-items-center gap-2 mb-4" role="alert">
                <i class="bi bi-exclamation-triangle-fill fs-5"></i>
                <div><?= htmlspecialchars($_GET['erro']) ?></div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if (empty($produtosCarrinho)): ?>
            <div class="fc-card p-5 text-center my-4">
                <div class="mb-3">
                    <i class="bi bi-cart-x text-muted" style="font-size: 4rem;"></i>
                </div>
                <h2 class="h4 fw-bold text-dark mb-2">Seu carrinho está vazio</h2>
                <p class="text-muted mb-4">Adicione medicamentos e produtos para iniciar a venda.</p>
                <div>
                    <a href="produtosbalconista.php" class="btn btn-danger btn-touch px-4 rounded-pill fw-bold">
                        <i class="bi bi-search me-1"></i> Ver Catálogo de Produtos
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <!-- Coluna de Itens -->
                <div class="col-12 col-lg-8">
                    <!-- Visão Mobile (Cards de Itens) -->
                    <div class="d-lg-none">
                        <?php foreach ($produtosCarrinho as $item): ?>
                            <div class="fc-card p-3 mb-3">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <div class="fw-bold text-dark fs-6"><?= htmlspecialchars($item['nome']) ?></div>
                                    <form action="removercarrinho.php" method="POST">
                                        <input type="hidden" name="produto_id" value="<?= $item['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger border-0 p-1" title="Remover item">
                                            <i class="bi bi-trash fs-5"></i>
                                        </button>
                                    </form>
                                </div>
                                <div class="d-flex justify-content-between align-items-center text-muted small mb-3">
                                    <span>Unitário: R$ <?= number_format($item['preco'], 2, ',', '.') ?></span>
                                    <span class="fs-6 fw-bold text-danger">Subtotal: R$ <?= number_format($item['subtotal'], 2, ',', '.') ?></span>
                                </div>
                                <form action="atualizarcarrinho.php" method="POST" class="d-flex align-items-center gap-2">
                                    <input type="hidden" name="produto_id" value="<?= $item['id'] ?>">
                                    <div class="input-group input-group-sm">
                                        <span class="input-group-text bg-light text-muted">Qtd:</span>
                                        <input 
                                            type="number" 
                                            name="quantidade" 
                                            class="form-control text-center fw-bold" 
                                            value="<?= $item['quantidade'] ?>" 
                                            min="1" 
                                            max="<?= $item['estoque'] ?>" 
                                            required
                                        >
                                        <button class="btn btn-danger" type="submit">
                                            <i class="bi bi-arrow-repeat"></i> Atualizar
                                        </button>
                                    </div>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Visão Desktop (Tabela) -->
                    <div class="d-none d-lg-block fc-card p-0">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th class="ps-4">Produto</th>
                                        <th style="width: 180px;">Quantidade</th>
                                        <th>Preço Unitário</th>
                                        <th>Subtotal</th>
                                        <th class="text-end pe-4" style="width: 80px;">Ação</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($produtosCarrinho as $item): ?>
                                        <tr>
                                            <td class="ps-4 fw-bold text-dark"><?= htmlspecialchars($item['nome']) ?></td>
                                            <td>
                                                <form action="atualizarcarrinho.php" method="POST" class="d-flex align-items-center gap-1">
                                                    <input type="hidden" name="produto_id" value="<?= $item['id'] ?>">
                                                    <input 
                                                        type="number" 
                                                        name="quantidade" 
                                                        class="form-control form-control-sm text-center fw-bold rounded-pill" 
                                                        value="<?= $item['quantidade'] ?>" 
                                                        min="1" 
                                                        max="<?= $item['estoque'] ?>" 
                                                        style="width: 75px;" 
                                                        required
                                                    >
                                                    <button type="submit" class="btn btn-sm btn-outline-secondary rounded-pill" title="Atualizar">
                                                        <i class="bi bi-arrow-repeat"></i>
                                                    </button>
                                                </form>
                                            </td>
                                            <td>R$ <?= number_format($item['preco'], 2, ',', '.') ?></td>
                                            <td class="fw-bold text-danger">R$ <?= number_format($item['subtotal'], 2, ',', '.') ?></td>
                                            <td class="text-end pe-4">
                                                <form action="removercarrinho.php" method="POST" onsubmit="return confirm('Remover este item do carrinho?');">
                                                    <input type="hidden" name="produto_id" value="<?= $item['id'] ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-danger rounded-pill" title="Remover">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Coluna de Fechamento de Venda -->
                <div class="col-12 col-lg-4">
                    <div class="checkout-summary-box shadow-sm">
                        <h2 class="h5 fw-bold text-dark pb-2 border-bottom mb-3 d-flex align-items-center gap-2">
                            <i class="bi bi-cash-coin text-danger"></i> Resumo da Venda
                        </h2>

                        <!-- Total Destaque -->
                        <div class="p-3 bg-light rounded-3 mb-3 text-center border">
                            <div class="text-muted small text-uppercase fw-bold">Total a Pagar</div>
                            <div class="fs-2 fw-bold text-danger">
                                R$ <?= number_format($total, 2, ',', '.') ?>
                            </div>
                            <small class="text-muted"><?= $quantidadeCarrinho ?> item(ns) no pedido</small>
                        </div>

                        <!-- Formulário de Pagamento -->
                        <form method="POST" action="finalizarvenda.php" id="formFinalizarVenda">
                            <div class="mb-3">
                                <label for="nome-cliente" class="form-label small fw-bold text-secondary">
                                    Nome do Cliente
                                </label>
                                <input 
                                    id="nome-cliente" 
                                    name="nome_cliente" 
                                    type="text" 
                                    class="form-control form-control-touch" 
                                    placeholder="Ex: João da Silva (ou Consumidor)"
                                >
                            </div>

                            <div class="mb-3">
                                <label for="cpf-cliente" class="form-label small fw-bold text-secondary">
                                    CPF do Cliente <span class="text-muted fw-normal">(Opcional)</span>
                                </label>
                                <input 
                                    id="cpf-cliente" 
                                    name="cpf_cliente" 
                                    type="text" 
                                    class="form-control form-control-touch" 
                                    placeholder="000.000.000-00" 
                                    maxlength="14"
                                    inputmode="numeric"
                                >
                            </div>

                            <div class="mb-3">
                                <label for="forma-pagamento" class="form-label small fw-bold text-secondary">
                                    Forma de Pagamento *
                                </label>
                                <select 
                                    id="forma-pagamento" 
                                    name="forma_pagamento" 
                                    class="form-select form-select-touch" 
                                    onchange="gerenciarFormaPagamento()" 
                                    required
                                >
                                    <option value="" disabled selected>Selecione a forma...</option>
                                    <option value="dinheiro">💵 Dinheiro (Calcula Troco)</option>
                                    <option value="pix">⚡ Pix (QR Code / Chave)</option>
                                    <option value="debito">💳 Cartão de Débito</option>
                                    <option value="credito">💳 Cartão de Crédito</option>
                                </select>
                            </div>

                            <!-- Campo Dinheiro & Troco -->
                            <div id="campo-dinheiro" class="mb-3 d-none">
                                <label for="valor-recebido" class="form-label small fw-bold text-secondary">
                                    Valor Recebido em Dinheiro *
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light fw-bold">R$</span>
                                    <input 
                                        id="valor-recebido" 
                                        name="valor_recebido" 
                                        type="number" 
                                        class="form-control form-control-touch" 
                                        min="<?= number_format($total, 2, '.', '') ?>" 
                                        step="0.01" 
                                        placeholder="0,00" 
                                        oninput="calcularTroco()"
                                    >
                                </div>
                                
                                <div class="troco-destaque mt-2 d-flex justify-content-between align-items-center">
                                    <span class="fw-bold">Troco a devolver:</span>
                                    <span class="fs-5 fw-bold text-success" id="troco-mostrado">R$ 0,00</span>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-danger btn-touch w-100 mt-3 shadow py-3 fs-6">
                                <i class="bi bi-check2-circle fs-5"></i>
                                <span>CONCLUIR E EMITIR RECIBO</span>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <?php renderScripts(1); ?>

    <script>
        const totalVenda = <?= json_encode((float)$total) ?>;

        function gerenciarFormaPagamento() {
            const forma = document.getElementById('forma-pagamento').value;
            const campoDinheiro = document.getElementById('campo-dinheiro');
            const valorRecebido = document.getElementById('valor-recebido');

            if (forma === 'dinheiro') {
                campoDinheiro.classList.remove('d-none');
                valorRecebido.required = true;
                valorRecebido.focus();
                calcularTroco();
            } else {
                campoDinheiro.classList.add('d-none');
                valorRecebido.required = false;
                valorRecebido.value = '';
                document.getElementById('troco-mostrado').innerText = 'R$ 0,00';
            }
        }

        function calcularTroco() {
            const valorRecebido = parseFloat(document.getElementById('valor-recebido').value) || 0;
            const troco = Math.max(0, valorRecebido - totalVenda);
            document.getElementById('troco-mostrado').innerText = 'R$ ' + troco.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        }
    </script>
</body>
</html>
