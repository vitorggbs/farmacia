<?php
session_start();

require_once __DIR__ . '/../autenticacao.php';
require_once __DIR__ . '/../gerente/conexaoDB.php';
require_once __DIR__ . '/../cabecalho.php';

exigirLogin('balconista');

$usuarioId = (int) $_SESSION['usuario_id'];
$farmaciaId = (int) $_SESSION['farmacia_id'];
$nomeFarmacia = $_SESSION['farmacia_nome'] ?? 'Farmácia';
$nomeUsuario = $_SESSION['usuario_nome'] ?? 'Balconista';

$sql = 'SELECT COUNT(*) AS vendas,
        COALESCE(SUM(valor_total), 0) AS total
        FROM vendas
        WHERE usuario_id = ?
        AND farmacia_id = ?
        AND DATE(data_venda) = CURDATE()';

$stmt = mysqli_prepare($conexao, $sql);
mysqli_stmt_bind_param($stmt, 'ii', $usuarioId, $farmaciaId);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);
$res = mysqli_fetch_assoc($resultado);
mysqli_stmt_close($stmt);

$totalVendasHoje = (int) ($res['vendas'] ?? 0);
$faturamentoHoje = (float) ($res['total'] ?? 0.0);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <?php renderHead('FarmaCerta - Balconista', 1); ?>
</head>
<body>
    <?php cabecalho('FarmaCerta - Balconista', 'balconista', 'inicio'); ?>

    <main class="container my-4 flex-grow-1">
        <!-- Boas-vindas -->
        <div class="fc-card p-4 mb-4 border-0">
            <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">
                <div>
                    <span class="badge bg-danger-subtle text-danger px-3 py-2 rounded-pill fw-bold mb-2">
                        <i class="bi bi-shop me-1"></i> <?= htmlspecialchars($nomeFarmacia) ?>
                    </span>
                    <h1 class="h3 fw-bold mb-1 text-dark">Olá, <?= htmlspecialchars($nomeUsuario) ?>!</h1>
                    <p class="text-muted mb-0">Aqui está o resumo dos seus atendimentos de hoje.</p>
                </div>
                <div>
                    <a href="produtosbalconista.php" class="btn btn-danger btn-touch px-4 py-3 shadow-sm rounded-pill fw-bold d-inline-flex align-items-center gap-2">
                        <i class="bi bi-cart-plus-fill fs-5"></i>
                        <span>INICIAR NOVA VENDA</span>
                    </a>
                </div>
            </div>
        </div>

        <!-- KPIs do Dia -->
        <div class="row g-3 mb-4">
            <div class="col-12 col-sm-6">
                <div class="kpi-card h-100">
                    <div class="kpi-icon primary">
                        <i class="bi bi-receipt-cutoff"></i>
                    </div>
                    <div>
                        <div class="text-muted small text-uppercase fw-bold">Vendas Realizadas Hoje</div>
                        <div class="fs-2 fw-bold text-dark"><?= $totalVendasHoje ?></div>
                        <small class="text-secondary">Atendimentos concluídos</small>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6">
                <div class="kpi-card h-100">
                    <div class="kpi-icon success">
                        <i class="bi bi-cash-stack"></i>
                    </div>
                    <div>
                        <div class="text-muted small text-uppercase fw-bold">Total Vendido Hoje</div>
                        <div class="fs-2 fw-bold text-success">R$ <?= number_format($faturamentoHoje, 2, ',', '.') ?></div>
                        <small class="text-secondary">Em todas as formas de pagamento</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Ações Rápidas -->
        <div class="row g-3">
            <div class="col-12 col-md-6">
                <div class="fc-card p-4 h-100">
                    <h2 class="h5 fw-bold mb-3 d-flex align-items-center gap-2">
                        <i class="bi bi-grid-3x3-gap text-danger"></i> Catálogo de Produtos
                    </h2>
                    <p class="text-muted small mb-4">Consulte preços, disponibilidade em estoque e adicione itens diretamente ao carrinho de compras.</p>
                    <a href="produtosbalconista.php" class="btn btn-outline-danger btn-touch w-100 rounded-pill">
                        <i class="bi bi-search"></i> Acessar Catálogo
                    </a>
                </div>
            </div>

            <div class="col-12 col-md-6">
                <div class="fc-card p-4 h-100">
                    <h2 class="h5 fw-bold mb-3 d-flex align-items-center gap-2">
                        <i class="bi bi-clock-history text-danger"></i> Histórico de Recibos
                    </h2>
                    <p class="text-muted small mb-4">Visualize suas vendas recentes, reimprima comprovantes e consulte detalhes de pedidos concluídos.</p>
                    <a href="historicorecibobalconista.php" class="btn btn-outline-secondary btn-touch w-100 rounded-pill">
                        <i class="bi bi-receipt"></i> Ver Meus Recibos
                    </a>
                </div>
            </div>
        </div>
    </main>

    <?php renderScripts(1); ?>
</body>
</html>
