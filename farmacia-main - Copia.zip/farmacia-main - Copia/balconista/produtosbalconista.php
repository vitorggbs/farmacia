<?php
session_start();

require_once __DIR__ . '/../autenticacao.php';
require_once __DIR__ . '/../gerente/conexaoDB.php';
require_once __DIR__ . '/../cabecalho.php';

exigirLogin('balconista');

if (!isset($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = array();
}

$farmaciaId = (int) $_SESSION['farmacia_id'];
$nomeFarmacia = $_SESSION['farmacia_nome'] ?? 'Farmácia';
$quantidadeCarrinho = array_sum($_SESSION['carrinho']);

$sql = 'SELECT id, nome, preco, quantidade, imagem, prateleira
        FROM produtos
        WHERE farmacia_id = ? AND ativo = 1
        ORDER BY nome ASC';

$stmt = mysqli_prepare($conexao, $sql);
mysqli_stmt_bind_param($stmt, 'i', $farmaciaId);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);

$produtos = array();
while ($row = mysqli_fetch_assoc($resultado)) {
    $produtos[] = $row;
}
mysqli_stmt_close($stmt);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <?php renderHead('FarmaCerta - Produtos', 1); ?>
</head>
<body>
    <?php cabecalho('FarmaCerta - Balconista', 'balconista', 'produtos'); ?>

    <main class="container my-4 flex-grow-1">
        <!-- Header & Busca -->
        <div class="fc-card p-3 p-md-4 mb-4">
            <div class="row g-3 align-items-center justify-content-between">
                <div class="col-12 col-md-5">
                    <h1 class="h4 fw-bold mb-1 text-dark">
                        <i class="bi bi-grid-3x3-gap text-danger me-1"></i> Catálogo de Produtos
                    </h1>
                    <p class="text-muted small mb-0">Selecione os medicamentos para o carrinho de vendas.</p>
                </div>
                <div class="col-12 col-md-7">
                    <div class="input-group input-group-lg shadow-sm rounded-pill overflow-hidden border">
                        <span class="input-group-text bg-white border-0 ps-3">
                            <i class="bi bi-search text-danger"></i>
                        </span>
                        <input 
                            type="text" 
                            id="buscaInput" 
                            class="form-control border-0 ps-2 fs-6" 
                            placeholder="Buscar por nome do remédio ou prateleira..." 
                            onkeyup="filtrarCatalogo()"
                            aria-label="Buscar produto"
                        >
                        <button class="btn btn-light border-0 px-3 text-muted" type="button" onclick="limparBusca()" title="Limpar busca">
                            <i class="bi bi-x-circle"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Feedback Messages -->
        <?php if (isset($_GET['ok'])): ?>
            <div class="alert alert-success alert-dismissible fade show rounded-3 shadow-sm d-flex align-items-center gap-2 mb-4" role="alert">
                <i class="bi bi-check-circle-fill fs-5"></i>
                <div>Item adicionado ao carrinho com sucesso!</div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($_GET['erro'])): ?>
            <div class="alert alert-danger alert-dismissible fade show rounded-3 shadow-sm d-flex align-items-center gap-2 mb-4" role="alert">
                <i class="bi bi-exclamation-triangle-fill fs-5"></i>
                <div><?= htmlspecialchars($_GET['erro']) ?></div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Visão Mobile (Cards Touch-Friendly) -->
        <div class="d-md-none" id="produtosMobileContainer">
            <div class="row g-3" id="listaCardsProdutos">
                <?php if (empty($produtos)): ?>
                    <div class="col-12 text-center py-5 text-muted">
                        <i class="bi bi-inbox fs-1 d-block mb-2 text-secondary"></i>
                        Nenhum produto cadastrado no momento.
                    </div>
                <?php endif; ?>

                <?php foreach ($produtos as $p): 
                    $semEstoque = ($p['quantidade'] <= 0);
                ?>
                    <div class="col-12 col-sm-6 item-produto-card" data-nome="<?= mb_strtolower($p['nome']) ?>" data-prat="<?= mb_strtolower($p['prateleira'] ?? '') ?>">
                        <div class="product-card-touch <?= $semEstoque ? 'opacity-75' : '' ?>">
                            <div class="d-flex gap-3 align-items-start mb-2">
                                <div style="width: 80px; height: 80px; flex-shrink: 0;">
                                    <?php if (!empty($p['imagem']) && file_exists(__DIR__ . '/../gerente/uploads/' . $p['imagem'])): ?>
                                        <img src="../gerente/uploads/<?= htmlspecialchars($p['imagem']) ?>" alt="<?= htmlspecialchars($p['nome']) ?>" class="w-100 h-100 rounded-3 object-fit-cover">
                                    <?php else: ?>
                                        <div class="w-100 h-100 rounded-3 bg-light d-flex align-items-center justify-content-center text-secondary border">
                                            <i class="bi bi-capsule fs-3"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="flex-grow-1">
                                    <h2 class="h6 fw-bold text-dark mb-1 nome-produto"><?= htmlspecialchars($p['nome']) ?></h2>
                                    <div class="d-flex align-items-center gap-2 mb-1">
                                        <span class="badge <?= $semEstoque ? 'bg-danger' : 'bg-success-subtle text-success border border-success' ?> rounded-pill small">
                                            <?= $semEstoque ? 'Esgotado' : 'Estoque: ' . (int)$p['quantidade'] ?>
                                        </span>
                                        <?php if (!empty($p['prateleira'])): ?>
                                            <span class="badge bg-light text-secondary border rounded-pill small">
                                                Prat: <?= htmlspecialchars($p['prateleira']) ?>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="fs-5 fw-bold text-danger">
                                        R$ <?= number_format($p['preco'], 2, ',', '.') ?>
                                    </div>
                                </div>
                            </div>

                            <form action="adicionarcarrinho.php" method="POST" class="mt-auto pt-2 border-top">
                                <input type="hidden" name="produto_id" value="<?= $p['id'] ?>">
                                <div class="d-flex align-items-center gap-2">
                                    <div class="input-group input-group-sm" style="max-width: 110px;">
                                        <input 
                                            type="number" 
                                            name="quantidade" 
                                            class="form-control text-center fw-bold" 
                                            value="1" 
                                            min="1" 
                                            max="<?= (int)$p['quantidade'] ?>" 
                                            <?= $semEstoque ? 'disabled' : '' ?>
                                            aria-label="Quantidade"
                                        >
                                    </div>
                                    <button 
                                        type="submit" 
                                        class="btn btn-danger btn-sm rounded-pill flex-grow-1 fw-bold py-2 d-flex align-items-center justify-content-center gap-1"
                                        <?= $semEstoque ? 'disabled' : '' ?>
                                    >
                                        <i class="bi bi-cart-plus"></i>
                                        <span><?= $semEstoque ? 'Indisponível' : 'Adicionar' ?></span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Visão Desktop (Tabela Completa & Moderna) -->
        <div class="d-none d-md-block fc-card p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" id="tabelaDesktopProdutos">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4" style="width: 80px;">Foto</th>
                            <th>Produto</th>
                            <th>Prateleira</th>
                            <th>Preço Unitário</th>
                            <th>Estoque</th>
                            <th class="text-end pe-4" style="width: 240px;">Adicionar ao Carrinho</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($produtos)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-5 text-muted">
                                    Nenhum produto cadastrado no momento.
                                </td>
                            </tr>
                        <?php endif; ?>

                        <?php foreach ($produtos as $p): 
                            $semEstoque = ($p['quantidade'] <= 0);
                        ?>
                            <tr class="item-produto-linha" data-nome="<?= mb_strtolower($p['nome']) ?>" data-prat="<?= mb_strtolower($p['prateleira'] ?? '') ?>">
                                <td class="ps-4">
                                    <?php if (!empty($p['imagem']) && file_exists(__DIR__ . '/../gerente/uploads/' . $p['imagem'])): ?>
                                        <img src="../gerente/uploads/<?= htmlspecialchars($p['imagem']) ?>" alt="<?= htmlspecialchars($p['nome']) ?>" width="52" height="52" class="rounded-3 object-fit-cover shadow-sm">
                                    <?php else: ?>
                                        <div class="rounded-3 bg-light d-flex align-items-center justify-content-center text-secondary border" style="width: 52px; height: 52px;">
                                            <i class="bi bi-capsule fs-4"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="fw-bold text-dark nome-produto"><?= htmlspecialchars($p['nome']) ?></div>
                                </td>
                                <td>
                                    <span class="badge bg-light text-secondary border rounded-pill px-3 py-1">
                                        <?= htmlspecialchars($p['prateleira'] ?: '—') ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="fw-bold text-danger fs-6">
                                        R$ <?= number_format($p['preco'], 2, ',', '.') ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($semEstoque): ?>
                                        <span class="badge bg-danger rounded-pill px-3 py-1">Sem Estoque</span>
                                    <?php elseif ($p['quantidade'] <= 5): ?>
                                        <span class="badge bg-warning text-dark rounded-pill px-3 py-1">
                                            Baixo: <?= (int)$p['quantidade'] ?> un
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-success-subtle text-success border border-success rounded-pill px-3 py-1">
                                            <?= (int)$p['quantidade'] ?> disponíveis
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end pe-4">
                                    <form action="adicionarcarrinho.php" method="POST" class="d-inline-flex align-items-center justify-content-end gap-2">
                                        <input type="hidden" name="produto_id" value="<?= $p['id'] ?>">
                                        <input 
                                            type="number" 
                                            name="quantidade" 
                                            class="form-control form-control-sm text-center fw-bold rounded-pill" 
                                            value="1" 
                                            min="1" 
                                            max="<?= (int)$p['quantidade'] ?>" 
                                            style="width: 70px;"
                                            <?= $semEstoque ? 'disabled' : '' ?>
                                        >
                                        <button 
                                            type="submit" 
                                            class="btn btn-sm btn-danger rounded-pill px-3 fw-bold d-inline-flex align-items-center gap-1"
                                            <?= $semEstoque ? 'disabled' : '' ?>
                                        >
                                            <i class="bi bi-cart-plus"></i> Comprar
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Botão Flutuante Carrinho Mobile -->
        <a href="carrinhobalconista.php" class="cart-floating-badge d-lg-none" title="Ir para o Carrinho">
            <i class="bi bi-cart3"></i>
            <?php if ($quantidadeCarrinho > 0): ?>
                <span class="badge-count"><?= $quantidadeCarrinho ?></span>
            <?php endif; ?>
        </a>
    </main>

    <?php renderScripts(1); ?>

    <script>
        function filtrarCatalogo() {
            const termo = document.getElementById('buscaInput').value.trim().toLowerCase();
            
            // Filtro nos cards mobile
            document.querySelectorAll('.item-produto-card').forEach(card => {
                const nome = card.getAttribute('data-nome') || '';
                const prat = card.getAttribute('data-prat') || '';
                if (nome.includes(termo) || prat.includes(termo)) {
                    card.classList.remove('d-none');
                } else {
                    card.classList.add('d-none');
                }
            });

            // Filtro na tabela desktop
            document.querySelectorAll('.item-produto-linha').forEach(linha => {
                const nome = linha.getAttribute('data-nome') || '';
                const prat = linha.getAttribute('data-prat') || '';
                if (nome.includes(termo) || prat.includes(termo)) {
                    linha.classList.remove('d-none');
                } else {
                    linha.classList.add('d-none');
                }
            });
        }

        function limparBusca() {
            document.getElementById('buscaInput').value = '';
            filtrarCatalogo();
            document.getElementById('buscaInput').focus();
        }
    </script>
</body>
</html>
