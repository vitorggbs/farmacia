<?php
session_start();

require_once __DIR__ . '/../autenticacao.php';
require_once __DIR__ . '/../gerente/conexaoDB.php';
require_once __DIR__ . '/../cabecalho.php';

exigirLogin();

$farmaciaId = (int) $_SESSION['farmacia_id'];
$nomeFarmacia = $_SESSION['farmacia_nome'] ?? 'Farmácia';
$venda_id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($venda_id <= 0) {
    header('Location: iniciobalconista.php');
    exit;
}

$sqlVenda = 'SELECT
                v.valor_total,
                v.forma_pagamento,
                v.data_venda,
                v.cliente,
                v.valor_recebido,
                v.troco,
                v.usuario_id,
                u.nome AS vendedor_nome
             FROM vendas v
             LEFT JOIN usuarios u ON u.id = v.usuario_id
             WHERE v.id = ? AND v.farmacia_id = ?';

$stmtVenda = mysqli_prepare($conexao, $sqlVenda);
mysqli_stmt_bind_param($stmtVenda, 'ii', $venda_id, $farmaciaId);
mysqli_stmt_execute($stmtVenda);
$resVenda = mysqli_stmt_get_result($stmtVenda);
$venda = mysqli_fetch_assoc($resVenda);
mysqli_stmt_close($stmtVenda);

if (!$venda) {
    header('Location: historicorecibobalconista.php');
    exit;
}

// Bloqueio por permissão se balconista diferente
if ($_SESSION['cargo'] === 'balconista' && (int)$venda['usuario_id'] !== (int)$_SESSION['usuario_id']) {
    die('Acesso não autorizado a este comprovante.');
}

$stmtItens = mysqli_prepare(
    $conexao,
    "SELECT i.quantidade, p.nome, i.preco_unitario, i.subtotal
     FROM itens_venda i
     INNER JOIN produtos p ON p.id = i.produto_id
     WHERE i.venda_id = ? AND p.farmacia_id = ?
     ORDER BY i.id ASC"
);
mysqli_stmt_bind_param($stmtItens, 'ii', $venda_id, $farmaciaId);
mysqli_stmt_execute($stmtItens);
$resItens = mysqli_stmt_get_result($stmtItens);

$itens = array();
while ($row = mysqli_fetch_assoc($resItens)) {
    $itens[] = $row;
}
mysqli_stmt_close($stmtItens);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <?php renderHead('Comprovante de Venda #' . $venda_id, 1); ?>
</head>
<body>
    <div class="no-print">
        <?php cabecalho('FarmaCerta - Recibo', $_SESSION['cargo'], 'recibos'); ?>
    </div>

    <main class="container my-4 flex-grow-1">
        <!-- Barra de Ações -->
        <div class="d-flex align-items-center justify-content-between mb-4 no-print" style="max-width: 440px; margin: 0 auto;">
            <a href="produtosbalconista.php" class="btn btn-outline-secondary rounded-pill px-3 py-2 fw-semibold">
                <i class="bi bi-arrow-left"></i> Nova Venda
            </a>
            <button onclick="window.print()" class="btn btn-danger rounded-pill px-4 py-2 fw-bold shadow-sm d-inline-flex align-items-center gap-2">
                <i class="bi bi-printer-fill"></i> Imprimir Recibo
            </button>
        </div>

        <!-- Cupom Térmico Estilizado -->
        <div class="receipt-paper" id="cupom-recibo">
            <div class="text-center pb-3 border-bottom mb-3">
                <img src="../assets/LOGO_2.png" alt="Logo" width="48" height="48" class="mb-2">
                <h1 class="h5 fw-bold text-dark mb-1">FARMACERTA ERP</h1>
                <div class="text-muted small fw-bold text-uppercase"><?= htmlspecialchars($nomeFarmacia) ?></div>
                <div class="text-muted small">Comprovante de Venda Não Fiscal</div>
            </div>

            <!-- Dados do Pedido -->
            <div class="small mb-3">
                <div class="d-flex justify-content-between">
                    <span class="text-muted">Pedido:</span>
                    <strong>#<?= str_pad($venda_id, 6, '0', STR_PAD_LEFT) ?></strong>
                </div>
                <div class="d-flex justify-content-between">
                    <span class="text-muted">Data/Hora:</span>
                    <span><?= date('d/m/Y H:i:s', strtotime($venda['data_venda'])) ?></span>
                </div>
                <div class="d-flex justify-content-between">
                    <span class="text-muted">Atendente:</span>
                    <span><?= htmlspecialchars($venda['vendedor_nome'] ?? 'Balconista') ?></span>
                </div>
                <div class="d-flex justify-content-between">
                    <span class="text-muted">Cliente:</span>
                    <span><?= htmlspecialchars($venda['cliente'] ?: 'Consumidor Final') ?></span>
                </div>
            </div>

            <!-- Tabela de Itens -->
            <div class="table-responsive mb-3">
                <table class="table table-sm border-top border-bottom small mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Item</th>
                            <th class="text-center">Qtd</th>
                            <th class="text-end">Un.</th>
                            <th class="text-end">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($itens as $item): ?>
                            <tr>
                                <td><?= htmlspecialchars($item['nome']) ?></td>
                                <td class="text-center"><?= (int)$item['quantidade'] ?></td>
                                <td class="text-end"><?= number_format($item['preco_unitario'], 2, ',', '.') ?></td>
                                <td class="text-end fw-bold"><?= number_format($item['subtotal'], 2, ',', '.') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Totais e Pagamento -->
            <div class="small pt-2 border-top">
                <div class="d-flex justify-content-between fs-6 fw-bold text-dark mb-1">
                    <span>VALOR TOTAL:</span>
                    <span class="text-danger">R$ <?= number_format($venda['valor_total'], 2, ',', '.') ?></span>
                </div>
                <div class="d-flex justify-content-between text-muted">
                    <span>Forma de Pagamento:</span>
                    <strong class="text-uppercase"><?= htmlspecialchars($venda['forma_pagamento']) ?></strong>
                </div>

                <?php if ($venda['forma_pagamento'] === 'dinheiro'): ?>
                    <div class="d-flex justify-content-between text-muted">
                        <span>Valor Recebido:</span>
                        <span>R$ <?= number_format((float)$venda['valor_recebido'], 2, ',', '.') ?></span>
                    </div>
                    <div class="d-flex justify-content-between text-success fw-bold">
                        <span>Troco:</span>
                        <span>R$ <?= number_format((float)$venda['troco'], 2, ',', '.') ?></span>
                    </div>
                <?php endif; ?>
            </div>

            <div class="text-center pt-4 mt-3 border-top text-muted small">
                <p class="mb-1">Obrigado pela preferência!</p>
                <p class="small text-secondary mb-0">Guarde este comprovante.</p>
            </div>
        </div>
    </main>

    <?php renderScripts(1); ?>
</body>
</html>
