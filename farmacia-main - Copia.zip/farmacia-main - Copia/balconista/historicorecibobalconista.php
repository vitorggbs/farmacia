<?php
session_start();

require_once __DIR__ . '/../autenticacao.php';
require_once __DIR__ . '/../gerente/conexaoDB.php';
require_once __DIR__ . '/../cabecalho.php';

exigirLogin('balconista');

$usuarioId = (int) $_SESSION['usuario_id'];
$farmaciaId = (int) $_SESSION['farmacia_id'];

$sql = 'SELECT id, data_venda, cliente, forma_pagamento, valor_total 
        FROM vendas
        WHERE usuario_id = ? AND farmacia_id = ?
        ORDER BY id DESC';

$stmt = mysqli_prepare($conexao, $sql);
mysqli_stmt_bind_param($stmt, 'ii', $usuarioId, $farmaciaId);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);

$vendas = array();
while ($row = mysqli_fetch_assoc($resultado)) {
    $vendas[] = $row;
}
mysqli_stmt_close($stmt);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <?php renderHead('FarmaCerta - Meus Recibos', 1); ?>
</head>
<body>
    <?php cabecalho('FarmaCerta - Balconista', 'balconista', 'historico'); ?>

    <main class="container my-4 flex-grow-1">
        <div class="fc-card p-4 mb-4">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
                <div>
                    <h1 class="h4 fw-bold text-dark mb-1">
                        <i class="bi bi-clock-history text-danger me-1"></i> Meus Recibos
                    </h1>
                    <p class="text-muted small mb-0">Consulte e reimprima comprovantes de vendas efetuadas por você.</p>
                </div>
                <a href="produtosbalconista.php" class="btn btn-danger rounded-pill px-4 py-2 fw-bold d-inline-flex align-items-center gap-2">
                    <i class="bi bi-cart-plus"></i> Nova Venda
                </a>
            </div>
        </div>

        <!-- Visão Mobile (Cards de Recibo) -->
        <div class="d-md-none">
            <?php if (empty($vendas)): ?>
                <div class="fc-card p-4 text-center text-muted">
                    <i class="bi bi-receipt fs-1 d-block mb-2"></i>
                    Você ainda não realizou nenhuma venda.
                </div>
            <?php endif; ?>

            <?php foreach ($vendas as $v): ?>
                <div class="fc-card p-3 mb-3">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="badge bg-danger rounded-pill fw-bold">#<?= $v['id'] ?></span>
                        <span class="text-muted small"><?= date('d/m/Y H:i', strtotime($v['data_venda'])) ?></span>
                    </div>
                    <div class="fw-bold text-dark mb-1">
                        <?= htmlspecialchars($v['cliente'] ?: 'Consumidor Final') ?>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-2 pt-2 border-top">
                        <div>
                            <span class="badge bg-light text-dark border text-uppercase me-2"><?= htmlspecialchars($v['forma_pagamento']) ?></span>
                            <span class="fw-bold text-success fs-6">R$ <?= number_format($v['valor_total'], 2, ',', '.') ?></span>
                        </div>
                        <a href="recibobalconista.php?id=<?= $v['id'] ?>" class="btn btn-sm btn-outline-danger rounded-pill px-3 fw-bold">
                            <i class="bi bi-receipt"></i> Abrir
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Visão Desktop (Tabela) -->
        <div class="d-none d-md-block fc-card p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4">Número</th>
                            <th>Data/Hora</th>
                            <th>Cliente</th>
                            <th>Pagamento</th>
                            <th>Valor Total</th>
                            <th class="text-end pe-4">Ação</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($vendas)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-5 text-muted">
                                    Nenhum recibo encontrado.
                                </td>
                            </tr>
                        <?php endif; ?>

                        <?php foreach ($vendas as $v): ?>
                            <tr>
                                <td class="ps-4 fw-bold text-danger">#<?= $v['id'] ?></td>
                                <td><?= date('d/m/Y H:i', strtotime($v['data_venda'])) ?></td>
                                <td><?= htmlspecialchars($v['cliente'] ?: 'Consumidor Final') ?></td>
                                <td>
                                    <span class="badge bg-light text-dark border text-uppercase px-2 py-1">
                                        <?= htmlspecialchars($v['forma_pagamento']) ?>
                                    </span>
                                </td>
                                <td class="fw-bold text-success">
                                    R$ <?= number_format($v['valor_total'], 2, ',', '.') ?>
                                </td>
                                <td class="text-end pe-4">
                                    <a href="recibobalconista.php?id=<?= $v['id'] ?>" class="btn btn-sm btn-outline-danger rounded-pill px-3 fw-bold">
                                        <i class="bi bi-printer"></i> Ver Recibo
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <?php renderScripts(1); ?>
</body>
</html>
