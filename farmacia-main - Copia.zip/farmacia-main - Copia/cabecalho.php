<?php

if (!function_exists('renderHead')) {
    function renderHead($titulo, $nivelPasta = 1) {
        $prefix = str_repeat('../', $nivelPasta);
        $cssTime = file_exists(__DIR__ . '/style.css') ? filemtime(__DIR__ . '/style.css') : time();
        echo '
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
        <title>' . htmlspecialchars($titulo, ENT_QUOTES, 'UTF-8') . '</title>
        <link rel="icon" type="image/png" href="' . $prefix . 'assets/LOGO_2.png">
        <!-- Bootstrap 5.3.3 CSS -->
        <link rel="stylesheet" href="' . $prefix . 'assets/vendor/bootstrap/css/bootstrap.min.css">
        <!-- Bootstrap Icons -->
        <link rel="stylesheet" href="' . $prefix . 'assets/vendor/bootstrap-icons/bootstrap-icons.min.css">
        <!-- FarmaCerta Design System -->
        <link rel="stylesheet" href="' . $prefix . 'style.css?v=' . $cssTime . '">
        ';
    }
}

if (!function_exists('renderScripts')) {
    function renderScripts($nivelPasta = 1) {
        $prefix = str_repeat('../', $nivelPasta);
        echo '
        <!-- Bootstrap 5.3.3 JS Bundle -->
        <script src="' . $prefix . 'assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="' . $prefix . 'assets/js/fc-select.js"></script>
        ';
    }
}

function cabecalho($titulo, $pasta, $paginaAtiva = '')
{
    $nomeUsuario = htmlspecialchars($_SESSION['usuario_nome'] ?? 'Usuário', ENT_QUOTES, 'UTF-8');
    $nomeFarmacia = htmlspecialchars($_SESSION['farmacia_nome'] ?? 'Farmácia', ENT_QUOTES, 'UTF-8');
    $cargo = $_SESSION['cargo'] ?? $pasta;
    
    // Nível de pasta para links relativos
    $nivelPasta = ($pasta === 'funcionarios' || (isset($_SERVER['PHP_SELF']) && strpos($_SERVER['PHP_SELF'], '/funcionarios/') !== false)) ? 2 : 1;
    $prefixRoot = str_repeat('../', $nivelPasta);
    $prefixModulo = ($nivelPasta === 2) ? '../' : '';

    $inicio = ($pasta === 'gerente') ? $prefixModulo . 'iniciogerente.php' : $prefixModulo . 'iniciobalconista.php';
    $carrinhoQtd = isset($_SESSION['carrinho']) ? array_sum($_SESSION['carrinho']) : 0;
    ?>
    <header class="fc-navbar">
        <div class="container-fluid d-flex align-items-center justify-content-between">
            <!-- Brand Logo -->
            <a href="<?= $inicio ?>" class="d-flex align-items-center text-decoration-none me-3" title="Início FarmaCerta">
                <img src="<?= $prefixRoot ?>assets/LOGO_1.png" alt="FarmaCerta" class="fc-brand-img">
            </a>

            <!-- Desktop Nav Items -->
            <nav class="d-none d-lg-flex align-items-center gap-2">
                <?php if ($cargo === 'gerente'): ?>
                    <a href="<?= $prefixModulo ?>iniciogerente.php" class="fc-nav-link <?= $paginaAtiva === 'inicio' ? 'active' : '' ?>">
                        <i class="bi bi-speedometer2"></i> Início
                    </a>
                    <a href="<?= $prefixModulo ?>produtosgerente.php" class="fc-nav-link <?= $paginaAtiva === 'produtos' ? 'active' : '' ?>">
                        <i class="bi bi-box-seam"></i> Produtos
                    </a>
                    <a href="<?= $prefixModulo ?>movimentacoesestoque.php" class="fc-nav-link <?= $paginaAtiva === 'movimentacoes' ? 'active' : '' ?>">
                        <i class="bi bi-arrow-left-right"></i> Movimentações
                    </a>
                    <a href="<?= $prefixModulo ?>funcionarios/funcionarios.php" class="fc-nav-link <?= $paginaAtiva === 'funcionarios' ? 'active' : '' ?>">
                        <i class="bi bi-people"></i> Funcionários
                    </a>
                    <a href="<?= $prefixModulo ?>historicorecibogerente.php" class="fc-nav-link <?= $paginaAtiva === 'recibos' ? 'active' : '' ?>">
                        <i class="bi bi-receipt"></i> Recibos
                    </a>
                <?php else: ?>
                    <a href="<?= $prefixModulo ?>iniciobalconista.php" class="fc-nav-link <?= $paginaAtiva === 'inicio' ? 'active' : '' ?>">
                        <i class="bi bi-house-door"></i> Início
                    </a>
                    <a href="<?= $prefixModulo ?>produtosbalconista.php" class="fc-nav-link <?= $paginaAtiva === 'produtos' ? 'active' : '' ?>">
                        <i class="bi bi-grid-3x3-gap"></i> Produtos
                    </a>
                    <a href="<?= $prefixModulo ?>carrinhobalconista.php" class="fc-nav-link <?= $paginaAtiva === 'carrinho' ? 'active' : '' ?>">
                        <i class="bi bi-cart3"></i> Carrinho 
                        <?php if ($carrinhoQtd > 0): ?>
                            <span class="badge rounded-pill bg-white text-danger ms-1"><?= $carrinhoQtd ?></span>
                        <?php endif; ?>
                    </a>
                    <a href="<?= $prefixModulo ?>historicorecibobalconista.php" class="fc-nav-link <?= $paginaAtiva === 'historico' ? 'active' : '' ?>">
                        <i class="bi bi-clock-history"></i> Histórico
                    </a>
                <?php endif; ?>
            </nav>

            <!-- User Info & Actions -->
            <div class="d-flex align-items-center gap-2">
                <div class="fc-user-badge d-none d-sm-inline-flex">
                    <i class="bi bi-shop text-warning"></i>
                    <strong><?= $nomeFarmacia ?></strong>
                    <span class="opacity-50">|</span>
                    <i class="bi bi-person-circle"></i>
                    <span><?= $nomeUsuario ?> (<?= ucfirst($cargo) ?>)</span>
                </div>

                <?php if ($cargo === 'balconista'): ?>
                    <a href="<?= $prefixModulo ?>carrinhobalconista.php" class="btn btn-sm btn-light position-relative d-lg-none rounded-pill px-3 fw-bold text-danger" title="Ver Carrinho">
                        <i class="bi bi-cart3"></i>
                        <?php if ($carrinhoQtd > 0): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-dark">
                                <?= $carrinhoQtd ?>
                            </span>
                        <?php endif; ?>
                    </a>
                <?php endif; ?>

                <a class="fc-btn-logout d-none d-sm-inline-flex" href="<?= $prefixRoot ?>logout.php" title="Encerrar Sessão">
                    <i class="bi bi-box-arrow-right"></i> Sair
                </a>

                <!-- Hamburger Mobile Toggle -->
                <button class="btn btn-outline-light d-lg-none rounded-pill px-3 py-2 border-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#fcMobileMenu" aria-controls="fcMobileMenu" aria-label="Abrir Menu">
                    <i class="bi bi-list fs-5"></i>
                </button>
            </div>
        </div>
    </header>

    <!-- Offcanvas Menu Mobile -->
    <div class="offcanvas offcanvas-end fc-offcanvas" tabindex="-1" id="fcMobileMenu" aria-labelledby="fcMobileMenuLabel">
        <div class="offcanvas-header bg-danger text-white">
            <div class="d-flex align-items-center gap-2">
                <img src="<?= $prefixRoot ?>assets/LOGO_2.png" alt="Logo" width="32" height="32">
                <h5 class="offcanvas-title fw-bold mb-0" id="fcMobileMenuLabel">FarmaCerta ERP</h5>
            </div>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Fechar"></button>
        </div>
        <div class="offcanvas-body d-flex flex-column justify-content-between p-3">
            <div>
                <!-- Info do usuário no mobile -->
                <div class="p-3 mb-3 bg-light rounded-3 border">
                    <div class="d-flex align-items-center gap-2 text-secondary mb-1">
                        <i class="bi bi-shop text-danger"></i>
                        <span class="fw-bold text-dark"><?= $nomeFarmacia ?></span>
                    </div>
                    <div class="d-flex align-items-center gap-2 text-muted small">
                        <i class="bi bi-person-badge"></i>
                        <span><?= $nomeUsuario ?> (<?= ucfirst($cargo) ?>)</span>
                    </div>
                </div>

                <nav class="nav flex-column gap-2">
                    <?php if ($cargo === 'gerente'): ?>
                        <a href="<?= $prefixModulo ?>iniciogerente.php" class="fc-nav-link <?= $paginaAtiva === 'inicio' ? 'active' : '' ?>">
                            <i class="bi bi-speedometer2"></i> Início (Dashboard)
                        </a>
                        <a href="<?= $prefixModulo ?>produtosgerente.php" class="fc-nav-link <?= $paginaAtiva === 'produtos' ? 'active' : '' ?>">
                            <i class="bi bi-box-seam"></i> Gestão de Produtos
                        </a>
                        <a href="<?= $prefixModulo ?>movimentacoesestoque.php" class="fc-nav-link <?= $paginaAtiva === 'movimentacoes' ? 'active' : '' ?>">
                            <i class="bi bi-arrow-left-right"></i> Movimentações de Estoque
                        </a>
                        <a href="<?= $prefixModulo ?>funcionarios/funcionarios.php" class="fc-nav-link <?= $paginaAtiva === 'funcionarios' ? 'active' : '' ?>">
                            <i class="bi bi-people"></i> Equipe / Funcionários
                        </a>
                        <a href="<?= $prefixModulo ?>historicorecibogerente.php" class="fc-nav-link <?= $paginaAtiva === 'recibos' ? 'active' : '' ?>">
                            <i class="bi bi-receipt"></i> Histórico de Recibos
                        </a>
                    <?php else: ?>
                        <a href="<?= $prefixModulo ?>iniciobalconista.php" class="fc-nav-link <?= $paginaAtiva === 'inicio' ? 'active' : '' ?>">
                            <i class="bi bi-house-door"></i> Início (Resumo)
                        </a>
                        <a href="<?= $prefixModulo ?>produtosbalconista.php" class="fc-nav-link <?= $paginaAtiva === 'produtos' ? 'active' : '' ?>">
                            <i class="bi bi-grid-3x3-gap"></i> Catálogo / Vender
                        </a>
                        <a href="<?= $prefixModulo ?>carrinhobalconista.php" class="fc-nav-link <?= $paginaAtiva === 'carrinho' ? 'active' : '' ?>">
                            <i class="bi bi-cart3"></i> Carrinho de Compras
                            <?php if ($carrinhoQtd > 0): ?>
                                <span class="badge bg-danger text-white ms-auto"><?= $carrinhoQtd ?> itens</span>
                            <?php endif; ?>
                        </a>
                        <a href="<?= $prefixModulo ?>historicorecibobalconista.php" class="fc-nav-link <?= $paginaAtiva === 'historico' ? 'active' : '' ?>">
                            <i class="bi bi-clock-history"></i> Meus Recibos
                        </a>
                    <?php endif; ?>
                </nav>
            </div>

            <div class="pt-3 border-top mt-4">
                <a class="btn btn-outline-danger w-100 rounded-pill py-2 fw-bold d-flex align-items-center justify-content-center gap-2" href="<?= $prefixRoot ?>logout.php">
                    <i class="bi bi-box-arrow-right"></i> Sair do Sistema
                </a>
            </div>
        </div>
    </div>
    <?php
}
